# Ox — fundação sob SDD

**Estado do projeto:** fase `implementation-foundation`, aplicativo `not-yet-implemented`.
Esta entrega abre desenvolvimento delimitado pelo SDD e implementa a transição da
governança; ainda não existe aplicativo Rust/Iced executável. Autorizar uma feature
não significa aprovar sua implementação.

Autoridades: [constituição](docs/constitution.md), [AGENTS](AGENTS.md),
[contexto](sdd/project.md), [workflow](sdd/workflow.md) e
[ADR de transição](docs/decisions/implementation-transition.md).
Os três estudos externos continuam fora da distribuição e das dependências de validação.

## Navegação

- [Catálogo](.codex/skills/README.md): 29 skills (17 gerais, 3 condicionais, 9 especializações), com [perfil versionado](src/fixtures/profile.json) e [29 pontes](sdd/chain/README.md).
- [Workflow 1.3.0](sdd/workflow.md), [evidências schema 2](sdd/evidence.md) e [features](sdd/features/README.md).
- [Arquitetura prevista](docs/architecture/context.md), [pendências](docs/decisions/open-questions.md) e [fronteiras de confiança](docs/security/trust-boundaries.md).
- [Decisão e mapeamento da migração](docs/decisions/governance-externalization.md), [cobertura local](docs/validation/normative-coverage.md) e [relatório histórico](docs/validation/report.md) e [transição atual](docs/validation/implementation-transition/summary.md).
- [Proveniência](docs/structure/files.json) e baseline `docs/validation/adoption-baseline/copied-before-adaptation.tar.gz`: conservam cópias da biblioteca/SDD. Origens são rótulos históricos, sem acesso externo.

## Consulta explícita

Peça ao agente: “Leia .codex/skills/plugin-protocol-engineering/SKILL.md para revisar este contrato”. Para retomar: “Leia sdd/project.md e sdd/workflow.md e retome sdd/features/<nome>”. São instruções de conversa. Disponibilidade não ativa nem instala skills. Escolha uma primária pertinente e auxiliares somente para perguntas distintas. Não carregar a biblioteca inteira.

distributed-systems é condicional a garantias entre falhas independentes; engineering-productivity à avaliação de fluxos/ferramentas; prompt à autoria de prompts. gleam, kotlin e postgresql não estão no perfil.

## Verificação da governança e skills

Na raiz do Ox, Python 3.11+ e stdlib:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 sdd/tools/validate.py --root .
PYTHONDONTWRITEBYTECODE=1 python3 sdd/tools/validate.py --root . --structure-only
PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/check-ox.py
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s src/tests -v
PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/run-checks.py
PYTHONDONTWRITEBYTECODE=1 python3 sdd/tools/validate.py --root . --require-fresh
PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/package-ox.py
```

O runner conserva rodadas, logs, ambiente e hashes em `docs/validation/runs/`. O empacotador cria `ox-governance.zip` e relatório novos em `dist/`, inspeciona archives, extrai fora da árvore e executa os cinco comandos principais; não publica nada. O manifesto usa a allowlist da governança e exclui scratch, caches e arquivos da raiz fora desse contrato, incluindo futuros workspaces Cargo. Os testes usam cópia explícita e processos com auditoria de leitura da raiz de origem.

O modo padrão aceita pendências documentadas; `--structure-only` não aceita a mudança. `--require-fresh` confere vínculos de conteúdo, não adequação do oráculo. Não exigir aprovação global enquanto os 36 cenários técnicos das skills estiverem NÃO VERIFICADO.

## Histórico e limites

Scripts de autoria inicial e verify-boundary foram retirados da distribuição; não são comandos suportados. O backup anterior completo está fora do projeto; nomes/checksums da retirada estão na migração. Não há dependência desse backup. Observações antigas conservadas em archives/relatórios históricos não demonstram a configuração atual. As evidências correntes são as das features e do registro de transição; o relatório anterior conserva seu escopo histórico.

Skills copiadas, recursos, workflow, evidence, templates e validador SDD permanecem byte a byte. Estrutura, inspeção semântica, resposta observada de agente e integração de produto são níveis distintos. Licença comercial, plataforma e sandbox aguardam decisões antes de produto público; não são resolvidos por esta migração.

## Integração das skills com SDD

O [guia de uso](docs/development/sdd-skills.md) distingue indicação, seleção,
consulta e uso, com exemplos de rota local e completa. As pontes transportam IDs,
perguntas e resultados; as skills oferecem métodos, sem substituir autoridades.

## Verificação do aplicativo

Os comandos Python verificam governança, SDD e contratos das skills. Não comprovam
compilação Rust, integração Iced, eficácia de sandbox ou aceitação do aplicativo.
Comandos Cargo e CI serão registrados quando fontes e configurações reais existirem,
com testes e evidências próprios nas features de implementação.

## Pacote de governança

`src/scripts/package-ox.py` produz exclusivamente `ox-governance.zip`, com
`package_kind=governance` e `product_included=false` no ZIP e no recibo externo.
A allowlist não inclui `Cargo.toml`, `Cargo.lock`, `crates/`, binários ou instaladores.
O pipeline do aplicativo exigirá manifestos, build, testes e distribuição próprios.
O comando não publica o pacote.
