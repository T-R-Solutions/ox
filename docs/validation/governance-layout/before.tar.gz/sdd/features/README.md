# Índice das features SDD do Ox

As features desta pasta são independentes e permanecem diretamente em
`sdd/features/` conforme o validador SDD 1.3.0 adotado.

## Governança histórica

- `adoption-governance`: adoção da biblioteca e autoridades.
- `governance-externalization`: retirada de dependências de estudos externos.

Os resultados históricos permanecem na baseline. Envelopes ativos afetados
recebem observações novas conforme evidence.md; não se reaproveitam hashes antigos.

## Biblioteca de skills

- `skill-*`: autoria, roteamento e avaliação das nove especializações.
- Critérios técnicos que exigem subsistemas reais continuam NÃO VERIFICADO
  quando não há evidência de implementação.

## Produto Ox

- `product-foundation`: transição de fase e preparação verificável da fundação.
- Futuras `product-*`: módulos Rust/Iced, plugins, runtime, contexto,
  grafos, verificação e demais capacidades, cada uma com evidências próprias.

A rota local segue `sdd/workflow.md`. Não mover features para escapar dos gates,
não promover aprovações históricas e não confundir documentação com implementação.
