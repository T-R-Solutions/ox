# Resultado da preparação Ox

Concluída a criação autorizada da governança, biblioteca, nove SDDs de autoria e verificadores locais em 2026-10-26. O aplicativo, crates, interface, serviços e plugins não foram implementados ou validados.

## Entrega observada

- 29 skills: 17 gerais e 3 condicionais copiadas integralmente, mais 9 especializações novas (5 P0, 4 P1). Cada nova tem 3 referências técnicas substantivas e 1 referência de avaliação; total de 36 referências novas.
- 29 pontes operacionais: 20 copiadas/adaptadas e 9 materializadas dos contratos propostos, com skill_path relativo e identidade conferida. Nenhuma ponte de gleam, kotlin ou postgresql.
- Modelo SDD 1.3.0 diretamente em sdd, sem sdd/model. Workflow, evidence, templates e ferramenta de validação preservados byte a byte; cache Python não copiado.
- AGENTS conciso; constituição única em docs; apontador em sdd; contexto, decisões abertas, fontes, segurança e cobertura das 72 regras normativas. Requisitos GUI mantidos futuros.
- Dez features: adoção e nove autorias `skill-*`. As 36 declarações técnicas originais AC-01..04 foram preservadas, com decisões, riscos, cenários e retomada. Não há feature de produto aprovada.
- Baselines recuperáveis dos originais e componentes antes de adaptar; manifesto com hashes realmente calculados e revisões acrescentadas, diff revisado e snapshot dos componentes.

## Verificações executadas

Ambiente: Linux, Python 3.13.16; stdlib no fluxo obrigatório. Sem repositório Git. PyYAML 6.0.3 já disponível foi usado somente no verificador opcional da skill-creator.

| Nível | Método/comando (cwd: raiz Ox) | Resultado e evidência |
|---|---|---|
| Estrutura SDD | `PYTHONDONTWRITEBYTECODE=1 python3 sdd/tools/validate.py --root .` | Exit 0 na [rodada inicial](runs/20261026T180053.837637Z/results.json) |
| Features em andamento | `PYTHONDONTWRITEBYTECODE=1 python3 sdd/tools/validate.py --root . --structure-only` | Exit 0, [checagem após fechar tasks/plan](final-structure-001/1.log) |
| Perfil/cópias/paths | `PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/check-ox.py` | Exit 0; 29 pares, cópias, núcleo SDD, originais e cobertura normativa; [log](final-structure-001/2.log) |
| Testes e cópia independente | `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s src/tests -v` | 8 testes passaram, inclusive Ox copiado em diretório isolado, corrupção de recurso e casos adversos; [rodada final](final-evidence-001/2.log) |
| Orquestração de checks | `PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/run-checks.py` | Quatro comandos com exit 0; logs e inputs preservados em diretório único da rodada inicial |
| Metadata das novas | `PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/check-new-skills.py` | 9 entradas válidas; [registro](quick-validate-001.json) |
| Atualidade das evidências | `PYTHONDONTWRITEBYTECODE=1 python3 sdd/tools/validate.py --root . --require-fresh` | Exit 0, schema 2 e inputs atuais das observações; [checagem final](final-freshness-002/result.json). Não solicitada aprovação estrita global |
| Preservação externa | `PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/verify-boundary.py --source-root ..` | 3.117 arquivos externos comparados, zero alteração; 3 documentos originais iguais; [registro](boundary-20261026T180107.275730Z.json) |

A segunda execução dos testes ocorreu porque convergência, tasks/plan e evidências mudaram: verificou a cópia independente com o estado final. Não houve falha encoberta, alteração de critério para passar ou runner da biblioteca externa. Cada resultado anterior continua preservado; os documentos anteriores à convergência estão em `pre-convergence/documents.tar.gz`.

## Distinção das evidências

**Revisão semântica:** [conteúdo e fronteiras](semantic-review.md), [72 regras por ID](normative-coverage.md) e diff em `docs/structure/revisions/adoption-002/reviewed.diff`; feita pelo agente executor, sem alegação de revisão humana independente.

**Simulação controlada:** oito testes dos verificadores com critérios/JSON duplicados, caminhos/symlinks adversos, ponte inválida, ausência de evidência, invalidação seletiva e corrupção de cópia. São testes da governança local, não implementações dos subsistemas do Ox.

**Avaliação observada com agente:** [27 respostas revisadas](agent-evals/review.md), sendo 9 seleções positivas, 9 exclusões negativas e 9 cenários adversos. Respostas integrais, prompts, hashes e limitações estão preservados. Dois encaminhamentos negativos diferiram do nome sugerido, com justificativa compatível com as fronteiras. Exemplos próximos aos casos, exposição incidental dos prompts de comportamento no grupo 2 e versão/seed do modelo não expostas limitam generalização. Não é benchmark comparativo.

**Integração real do produto:** não executada. Não há runtime, sandbox, parser/índice, GUI, host ou provedor integrado para os oráculos dos 36 critérios técnicos originais. Respostas documentais que propõem esses testes não contam como sua execução.

## Estados e pendências

22 critérios APROVADO no escopo delimitado: 4 da adoção, 9 de conteúdo/estrutura e 9 de respostas textuais observadas. 36 critérios técnicos AC-01..04 continuam NÃO VERIFICADO. A aceitação global de cada feature de skill não é promovida artificialmente; T004 conserva retomada por cenário/oráculo e consumidor autorizado. Nenhuma aprovação implica produto Ox funcional ou seguro.

[Decisões abertas](../decisions/open-questions.md): plataformas, MSRV/edition/versões, runtime, agentes iniciais e rede, persistência/retenção, sandbox, distribuição/licença, parsers e metas de desempenho/acessibilidade. [Fontes oficiais](official-sources.md) registram versões consultadas e lacunas de documentação detalhada Iced/LSP e migração OTel. Não é necessário resolver essas escolhas para usar a biblioteca como conhecimento reutilizável.

Para retomar integração: escolher consumidor e ambiente autorizado, ler spec/plan/tasks/converge da skill, executar seus quatro cenários preservados com implementação/oráculo reais e registrar novos inputs/resultados. Não há comando de produto a inventar enquanto não existe implementação.

## Limite de escrita e portabilidade

Todas as criações e alterações desta preparação ficaram dentro de Ox, incluindo agentes internos, fixtures, snapshots, logs e resultados. A inspeção por hashes confirmou a biblioteca, AGENTS externo e arquivos gerenciados sem alteração de conteúdo. O método não atesta timestamps de acesso nem mudanças transitórias revertidas. A verificação normal e o teste de cópia independente não dependem da biblioteca externa; apenas o auditor histórico de fronteira recebe explicitamente a raiz original para leitura.

O [reexame de proveniência](convergence-review.md) distingue inputs efetivamente usados nos ensaios de agente dos contratos finais revisados posteriormente. Metadados anteriores foram preservados, e a nova checagem de freshness passou após essa correção, sem fingir reexecução dos agentes.
