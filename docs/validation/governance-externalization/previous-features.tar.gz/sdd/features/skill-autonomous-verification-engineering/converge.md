# Convergência após correção de localização

Skills agora em `.codex/skills/`. Inspeção atual E-RELOCATION em evidence.json; observações e convergência anteriores preservadas em docs/validation/skills-location-001/before.tar.gz. A mudança de path não é reexecução dos agentes nem implementação de produto.

| Critério | Vínculo | Implementação | Evidência | Estado |
|---|---|---|---|---|
| AC-01 | REQ-01 / D-01 / R-01 / T001, T004 | `.codex/skills/autonomous-verification-engineering/SKILL.md` | Oráculo técnico ainda não executado | NÃO VERIFICADO |
| AC-02 | REQ-02 / D-01 / R-01 / T001, T004 | `.codex/skills/autonomous-verification-engineering/SKILL.md` | Oráculo técnico ainda não executado | NÃO VERIFICADO |
| AC-03 | REQ-02 / D-01 / R-01 / T001, T004 | `.codex/skills/autonomous-verification-engineering/SKILL.md` | Oráculo técnico ainda não executado | NÃO VERIFICADO |
| AC-04 | REQ-03 / D-01 / R-01 / T001, T004 | `.codex/skills/autonomous-verification-engineering/SKILL.md` | Oráculo técnico ainda não executado | NÃO VERIFICADO |
| AC-05 | REQ-04 / D-03 / R-03 / T002, T003, T005 | `.codex/skills/autonomous-verification-engineering/SKILL.md` | E-RELOCATION: revisão atual; resultados originais preservados | APROVADO |
| AC-06 | REQ-04 / D-03 / R-03 / T002, T003, T005 | `.codex/skills/autonomous-verification-engineering/SKILL.md` | E-RELOCATION: revisão atual; resultados originais preservados | APROVADO |

## Limites e retomada

Autoria materializada e verificada localmente; aceitação global desta feature permanece pendente dos quatro cenários técnicos originais, sem reduzir critérios. Não há aprovação de funcionalidades do Ox. Revisão do autor, ensaio de agente, simulação dos verificadores e integração de produto são níveis distintos.

Retome T004 lendo spec/plan/tasks, confirme consumidor, versões, plataforma, dados descartáveis e escopo autorizado; implemente ou localize o harness descrito no oráculo de cada AC-01..04 e execute o cenário preservado. Sem consumidor não há comando real de integração a inventar. Registre comando então observado, resultados e hashes; mantenha estado NÃO VERIFICADO até lá. Para rever somente a autoria, execute os comandos stdlib de sdd/project.md e forneça os prompts de src/fixtures ao agente autorizado, preservando nova rodada. Mudanças nos inputs de evidence.json invalidam apenas observações dependentes; não atualize hashes antigos para reutilizá-las.
