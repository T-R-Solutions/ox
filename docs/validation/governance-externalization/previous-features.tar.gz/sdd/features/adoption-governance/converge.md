# Convergência após correção de localização

Skills agora em `.codex/skills/`. Inspeção atual E-RELOCATION em evidence.json; observações e convergência anteriores preservadas em docs/validation/skills-location-001/before.tar.gz. A mudança de path não é reexecução dos agentes nem implementação de produto.

| Critério | Vínculo | Implementação | Evidência | Estado |
|---|---|---|---|---|
| AC-01 | REQ-01 / D-01 / R-01 / T001 | `docs/structure/files.json` | E-RELOCATION: revisão atual; resultados originais preservados | APROVADO |
| AC-02 | REQ-02 / D-02 / R-02 / T002 | `.codex/skills/README.md` | E-RELOCATION: revisão atual; resultados originais preservados | APROVADO |
| AC-03 | REQ-03 / D-03 / R-03 / T003 | `AGENTS.md` | E-RELOCATION: revisão atual; resultados originais preservados | APROVADO |
| AC-04 | REQ-04 / D-04 / R-04 / T004 | `src/scripts/run-checks.py` | E-RELOCATION: revisão atual; resultados originais preservados | APROVADO |

## Limites e retomada

Os 36 critérios AC-01..04 das nove features de skill permanecem NÃO VERIFICADO; esta adoção não os substitui nem aprova funcionalidades Ox. AC-05/06 de cada uma aprovam conteúdo e ensaios textuais delimitados. Pendências de plataforma, versões, agentes, armazenamento, sandbox, distribuição e desempenho estão em docs/decisions/open-questions.md.

Para manutenção local, ler spec/plan/tasks/converge e comparar os inputs atuais com evidence.json. Executar os comandos existentes em sdd/project.md apenas quando mudança/risco invalidar observações. Para integração futura retomar T004 de cada skill em consumidor autorizado, com o oráculo e cenário originais; registrar comandos reais quando implementação/ambiente existirem. Não solicitar aprovação estrita global enquanto critérios obrigatórios continuarem sem evidência.
