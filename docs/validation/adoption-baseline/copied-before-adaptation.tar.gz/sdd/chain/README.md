# Pontes instaladas neste projeto

Esta pasta começa sem pontes específicas. Copie aqui somente os Markdown escolhidos
do catálogo Chain da biblioteca. Cada ponte tem `skill`, `skill_path` e
`bridge_version` no cabeçalho. `skill_path` é relativo à raiz do projeto, não à ponte.
Ajuste o valor UNCONFIGURED antes de usar ou validar a ponte.

Não copie as skills para esta pasta: copie suas pastas completas para um local
adequado e autorizado e indique o caminho de cada SKILL.md na ponte correspondente.
As pontes são documentos, não skills do Codex, scripts ou comandos executáveis.

O fluxo consulta as pontes existentes; não há registro adicional para sincronizar.
Sem pontes o SDD funciona normalmente. Dependências de especialidades são sugestões
condicionais; ausência de uma auxiliar não aciona instalação ou delegação automática.

Mantenha o método técnico na skill e os requisitos concretos na spec. Uma ponte
traduz entradas e resultados entre esses dois contextos e não substitui nenhum deles.

## Relação com as rotas

As contribuições spec/plan/tasks das pontes se aplicam ao fluxo completo e às features
existentes afetadas. Uma mudança local sem feature pode usar a skill isoladamente,
sem ponte, mantendo seu próprio registro proporcional. A ponte não exige criar uma
feature nem permite dispensar critérios/evidências já exigidos pelo projeto.
