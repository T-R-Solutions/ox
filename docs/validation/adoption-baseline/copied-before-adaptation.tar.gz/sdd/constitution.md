# Constituição inicial

Este é um ponto de partida a revisar na adoção, não uma política que substitui a do
projeto. Se já existir constituição, registre sua localização em project.md e use-a
como autoridade; este texto passa a ser apenas material de adaptação.

1. Preserve dados, mudanças anteriores e configurações fora do escopo autorizado.
2. Mantenha uma autoridade por regra: princípios na constituição, comportamento na
   spec, decisões no plan/ADRs, trabalho nas tasks e observações nas evidências.
3. Verifique riscos proporcionais à superfície alterada. Não invente resultados,
   permissões, ferramentas disponíveis ou garantias de segurança e desempenho.
4. Torne decisões e mudanças rastreáveis a critérios observáveis. Pendência ou
   ausência de evidência não equivale a aprovação.
5. Resolva conflitos na fonte, registrando motivo, alcance e condição de revisão
   das exceções. Nenhuma ponte ou método especializado altera requisitos por conta própria.

Registre data, responsável e justificativa de adoção ou alteração no projeto.
