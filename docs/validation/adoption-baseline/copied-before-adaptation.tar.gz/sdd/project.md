# Contexto do projeto

Preencher ao adotar, sem duplicar conteúdo já mantido em outro documento.
Valores não preenchidos são questões abertas, nunca fatos ou comandos executáveis.

- Objetivo e fronteiras do projeto: a preencher.
- Instruções existentes e constituição autoritativa: a preencher; reconciliar com constitution.md.
- Local dos requisitos, decisões e tarefas existentes: a preencher.
- Diretório das novas features: `sdd/features/` por padrão; pode ser alterado.
- Linguagens, targets e versões verificadas: a preencher quando pertinentes.
- Comandos reais de build, testes e validação: descobrir no projeto; registrar aqui ou referenciar a autoridade existente.
- Restrições, dados protegidos e escopo autorizado: a preencher.
- Ajustes locais deste modelo e motivos: registrar apenas diferenças necessárias.

A localização de cada skill pertence à sua ponte, não a uma segunda lista aqui.
Não deduzir uma stack, política de segurança ou orçamento de desempenho de exemplos.
