# Convergência vigente — governance-externalization

Histórico anterior em `docs/validation/governance-externalization/previous-features.tar.gz`. E-EXT-* são observações desta revisão; nenhuma resposta de agente foi executada novamente.

| Critério | Requisito | Decisão / risco | Tarefas | Estado | Evidências |
|---|---|---|---|---|---|
| AC-01 | REQ-01 | D-01 / R-01 | T001, T006 | APROVADO | E-EXT-LOCAL, E-EXT-REVIEW |
| AC-02 | REQ-02 | D-02 / R-02 | T002, T006 | APROVADO | E-EXT-LOCAL, E-EXT-REVIEW |
| AC-03 | REQ-03 | D-03 / R-03 | T003, T006 | APROVADO | E-EXT-LOCAL, E-EXT-REVIEW |
| AC-04 | REQ-04 | D-04 / R-04 | T004, T006 | APROVADO | E-EXT-LOCAL, E-EXT-REVIEW |

Métodos, artefatos, hashes e inputs constam de evidence.json. Limites: estrutura e inspeção não são implementação do produto; eficácia geral/modelos não reavaliados. A nova aceitação da adoção usa seus critérios explicitamente substituídos.
