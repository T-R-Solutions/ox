# Features de governança e autoria

`adoption-governance` registra a adoção com critérios substituídos explicitamente; `governance-externalization` registra a migração para autoridades locais e distribuição independente. Nove diretórios `skill-*` registram autoria/avaliação, não funcionalidades do produto. Futuras features `product-*` precisam de critérios e evidências independentes. Não mover features para escapar de gates; o validador percorre os diretórios diretos desta pasta.
