# Convergência vigente — governance-externalization

Histórico anterior em `docs/validation/governance-externalization/previous-features.tar.gz`. E-EXT-* são observações desta revisão; nenhuma resposta de agente foi executada novamente.

| Critério | Requisito | Decisão / risco | Tarefas | Estado | Evidências |
|---|---|---|---|---|---|
| AC-01 | REQ-01 | D-01 / R-01 | T001, T004 | NÃO VERIFICADO | Integração pendente; executar oráculo da spec com consumidor autorizado |
| AC-02 | REQ-02 | D-01 / R-01 | T001, T004 | NÃO VERIFICADO | Integração pendente; executar oráculo da spec com consumidor autorizado |
| AC-03 | REQ-03 | D-01 / R-01 | T001, T004 | NÃO VERIFICADO | Integração pendente; executar oráculo da spec com consumidor autorizado |
| AC-04 | REQ-03 | D-01 / R-01 | T001, T004 | NÃO VERIFICADO | Integração pendente; executar oráculo da spec com consumidor autorizado |
| AC-05 | REQ-04 | D-03 / R-03 | T002, T003, T005 | APROVADO | E-EXT-LOCAL, E-EXT-REVIEW |
| AC-06 | REQ-04 | D-03 / R-03 | T002, T003, T005 | APROVADO | E-EXT-LOCAL, E-EXT-REVIEW |

Métodos, artefatos, hashes e inputs constam de evidence.json. Limites: estrutura e inspeção não são implementação do produto; eficácia geral/modelos não reavaliados. A nova aceitação da adoção usa seus critérios explicitamente substituídos.
