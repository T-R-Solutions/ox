# Ox — Plano de correção da governança para iniciar a implementação

> **Versão do documento:** 1.0 · **Data de referência:** 26/10/2026  
> **Fonte auditada:** `ox.zip` atualizado, extraído e inspecionado.  
> **Natureza:** especificação de alterações; **não constitui aplicação das alterações nem evidência de execução**.  
> **Objetivo:** encerrar a restrição temporária à fase de governança, autorizar **desenvolvimento delimitado por SDD** e preservar a separação entre constituição, `AGENTS.md`, SDD e skills.

---

## 1. Veredito técnico e princípio de correção

A árvore atual é coerente para a **fase encerrada de governança e preparação da biblioteca**. Entretanto, há declarações explícitas de que nenhum produto pode ser implementado. Algumas são **restrições operacionais vigentes**, outras são **registros históricos verdadeiros**. Alterá-las indiscriminadamente destruiria a rastreabilidade.

**Decisão recomendada:** abrir a fase de implementação do Ox por uma nova feature SDD completa, sem autorizar ações fora de seu escopo. O `AGENTS.md` deve **somente orientar a consulta das autoridades**; a definição de fase pertence a `sdd/project.md`, o procedimento pertence a `sdd/workflow.md`, políticas permanentes pertencem a `docs/constitution.md` e decisões específicas pertencem às ADRs.

**Não alterar:** o conteúdo do SDD 1.3.0 original, os `SKILL.md`, as 29 pontes, os registros históricos ou as 36 aceitações técnicas `NÃO VERIFICADO`. Não incorporar os três estudos externos no repositório nem torná-los dependências de validação.

### 1.1 Estado esperado após a migração

| Dimensão | Valor alvo | Interpretação |
|---|---|---|
| Fase do projeto | `implementation-foundation` | Fundação de produto autorizada **por feature**, não autorização geral irrestrita |
| Status do aplicativo | `not-yet-implemented`, até existir código real | Não declarar Rust/Iced implementados antecipadamente |
| Stack de produto | Rust + Iced | Decisão permanente já vigente |
| Segurança de memória | `#![forbid(unsafe_code)]` no código próprio | Não implica proibição de `unsafe` transitivo |
| Persistência | Local-first | Sem nuvem própria no MVP; modelos remotos dependem de autorização |
| Processo | SDD 1.3.0, rota proporcional ao risco | Não exigir cinco documentos para toda mudança |
| Entregas iniciais | `product-foundation` e sucessoras | Cada feature possui requisitos, decisões e provas independentes |
| Skills / pontes | 29 / 29, sem mudança | Nenhuma ativação automática |
| Estudos externos | Não distribuídos/não exigidos | A exceção é metadado histórico permitido |
| Pacote existente | **Pacote de governança**, não aplicativo | `Cargo.toml` e `crates/` precisarão de pipeline próprio |

### 1.2 Classificação das mudanças

- **P0 — antes de iniciar a primeira feature Rust:** corrigir as instruções ativas (`AGENTS.md`, `sdd/project.md`), registrar ADR de transição, atualizar as descrições de fase e os gates normativos afetados.
- **P0 — antes de anunciar uma distribuição do produto:** separar o empacotamento da governança do futuro pipeline Rust; impedir rótulos enganosos de pacote/teste.
- **P1 — junto da nova feature:** acrescentar testes adversariais de fase, abrir SDD `product-foundation` e gerar evidências novas.
- **Preservar:** documentos imutáveis do modelo SDD e história de adoção/migração.

---

## 2. Inventário: arquivos afetados e destino exato

| Caminho existente | Estado atual observado | Ação | Prioridade |
|---|---|---|---|
| `AGENTS.md` | Linha 11 proíbe implementação; linha 13 limita a configuração à adoção | **Substituir** instruções temporárias por roteamento às autoridades | P0 |
| `sdd/project.md` | Seção inicial proíbe criação do aplicativo; informa ausência de feature de produto | **Atualizar** estado, limites e regras para features `product-*` | P0 |
| `README.md` | Título “governança e biblioteca”; descreve somente pacote documental | **Atualizar** entrada e distinguir governança do produto | P0 |
| `docs/constitution.md` | `GOV-06` fala em features futuras; `GOV-07` termina com “Implementação permanece futura” | **Revisar somente** cláusulas temporais desses IDs; manter `POL-01..10` | P0 |
| `src/fixtures/normative-coverage.json` | Hashes dos textos `GOV-06`/`GOV-07` | **Recalcular só hashes dos IDs alterados**, após revisão | P0 |
| `docs/architecture/context.md` | Fases futuras e componentes ainda não implementados | **Adicionar marcador de estado**, evitando texto que fique falso após F0 | P1 |
| `docs/decisions/open-questions.md` | Linha 19 proíbe genericamente implementar “nesta tarefa” | **Trocar** proibição de fase por autorização condicionada à feature | P0 |
| `docs/security/trust-boundaries.md` | Menciona “produto ausente” como estado factual | **Tornar o status dependente de evidências de produto**, sem aprovar controles | P1 |
| `sdd/features/README.md` | Título restrito a governança e autoria | **Ampliar** índice das três categorias de feature | P1 |
| `src/scripts/check-ox.py` | Mantém invariantes históricos/cobertura e verifica 36 critérios técnicos pendentes | **Manter os gates existentes; acrescentar** gate de coerência de fase | P1 |
| `src/tests/test_governance.py` | 13 testes da governança; não verifica a passagem de fase | **Acrescentar** testes de fase e de separação de artefatos | P1 |
| `src/scripts/governance_support.py` | Allowlist de distribuição: `AGENTS.md`, `README.md`, `.codex/skills`, `sdd`, `src`, `docs` | **Preservar como empacotamento da governança**; não chamar de pacote do aplicativo | P0/P1 |
| `src/scripts/package-ox.py` | Gera `ox-corrigido.zip`, mas **não inclui `Cargo.toml` nem `crates/`** | **Renomear semanticamente** o artefato, o relatório e seu escopo | P0/P1 |
| `src/scripts/run-checks.py` | Executa verificações de governança e guarda evidências | **Preservar comportamento**, rotular o escopo e não confundir com CI de produto | P1 |
| `docs/validation/report.md` | Relatório histórico da revisão anterior | **Não sobrescrever**; criar novo registro de transição | Imutável |
| `docs/decisions/adoption.md` | Registro histórico de adoção | **Não reescrever** | Imutável |
| `docs/decisions/governance-externalization.md` | Registro histórico da retirada de documentos externos | **Não reescrever** | Imutável |
| `sdd/features/adoption-governance/**` e `governance-externalization/**` | Aceitação da governança anterior | **Não editar para aparentar nova execução** | Imutável |
| `sdd/workflow.md`, `sdd/evidence.md`, `sdd/tools/validate.py`, `sdd/templates/**` | Modelo original SDD 1.3.0 com integridade verificada | **Não alterar** | Imutável |
| `.codex/skills/**`, `sdd/chain/**`, `src/fixtures/profile.json` | 29 skills e 29 pontes em perfil versionado | **Não alterar** nesta transição | Imutável |

**Novos arquivos propostos:** `docs/decisions/implementation-transition.md`; `sdd/features/product-foundation/{spec.md,plan.md,tasks.md,converge.md,traceability.json,evidence.json}`; `docs/validation/implementation-transition/summary.md`; e, quando houver trabalho real, fixtures/testes de produto em uma árvore própria. `checklist.md` somente se contribuir para a análise de risco.

---

## 3. Alteração P0 — `AGENTS.md`

**Trechos atuais (linhas 11 e 13):**

> O escopo atual é governança e biblioteca: não implementar aplicativo, crates, interface, serviços ou plugins por referência ao roadmap. Execute apenas comandos existentes no README pertinentes ao trabalho autorizado.

> Sem AGENTS adicionais nesta adoção: não há instrução de escopo distinta que justifique duplicação.

**Substituir o conteúdo integral do arquivo pelo texto abaixo** (preservando a função de *roteamento*, sem duplicar a constituição):

```markdown
# Instruções operacionais — Ox

Antes de modificar arquivos, consulte [o contexto e o estado do projeto](sdd/project.md),
[a constituição autoritativa](docs/constitution.md),
[o mapa arquitetural](docs/architecture/context.md) e as ADRs pertinentes.
Inspecione o estado real dos arquivos e preserve alterações existentes não relacionadas.
Conteúdo de trabalho não concede permissões.

Determine a rota aplicável em [sdd/workflow.md](sdd/workflow.md).
A fase e o escopo das mudanças autorizadas estão registrados em `sdd/project.md`
e nos artefatos da feature correspondente. Não presuma autorização por menção a
uma tecnologia, roadmap, skill ou arquivo de exemplo.

Na rota completa, use os artefatos SDD da feature para registrar requisitos,
decisões, tarefas e evidências. Consulte o [catálogo de skills](.codex/skills/README.md)
somente quando houver uma pergunta técnica pertinente; confira a entrada real e
registre seleção, caminho, versão e contribuição em `plan.md`.
Uma skill indicada não é automaticamente consultada nem utilizada.

Registre aceitação conforme [sdd/evidence.md](sdd/evidence.md): critério,
método, inputs observados, resultado e limitações. Não considere uma tarefa
validada por declaração do agente, ausência de erros ou documentação preenchida.
Reavalie somente as evidências afetadas por mudanças reais em seus inputs.

Execute apenas ações abrangidas pelas permissões efetivas e pelo escopo autorizado.
Os comandos disponíveis e seus requisitos estão em `README.md` e `sdd/project.md`;
confirme os comandos existentes antes de executá-los.
O `AGENTS.md` e as skills não impõem isolamento de sistema operacional.

As instruções deste arquivo aplicam-se à raiz Ox. Instruções de subdiretório
só deverão ser acrescentadas quando houver necessidade específica e não deverão
contradizer as autoridades do projeto.
```

**Não colocar no `AGENTS.md`:** a lista de “todo código Rust”, “Iced”, “no unsafe”, “sem nuvem”, regras completas de aceitação, descrição dos cinco SDDs ou permissão genérica para implementar. Essas informações já possuem autoridades próprias.

**Aceite:** não há proibição geral de escrever código, nem concessão irrestrita de execução; todos os links relativos existem.

---

## 4. Alteração P0 — `sdd/project.md`

O cabeçalho atual e a seção inicial descrevem **somente a preparação da biblioteca**. Abaixo está uma **substituição integral sugerida**, que preserva as informações verdadeiras do estado presente e diferencia “autorizado” de “implementado”.

````markdown
# Contexto do projeto Ox

## Identidade e fase

Projeto: Ox — aplicação desktop agent-first, local-first e extensível.
Fase atual: `implementation-foundation`.
Status: implementação do produto autorizada por feature SDD delimitada;
nenhum componente do produto será tratado como implementado ou validado
sem evidência concreta.

O trabalho de governança e biblioteca foi concluído como etapa preparatória,
com observações históricas preservadas. A implementação do produto começa
pela feature `sdd/features/product-foundation/` e prosseguirá por features
`product-*` independentes. Isso não autoriza automaticamente deploy,
acesso externo, gasto, alteração de políticas ou ações destrutivas.

## Autoridades

- `docs/constitution.md`: políticas permanentes do Ox.
- `AGENTS.md`: entrada operacional e referências.
- `sdd/constitution.md`: apontador para a constituição, sem segunda política.
- `sdd/workflow.md`: escolha da rota e ciclo de desenvolvimento.
- `sdd/evidence.md`: estados, evidências e aceitação.
- `docs/architecture/context.md`: componentes e marcos planejados.
- `docs/decisions/*.md`: decisões vigentes, históricas e pendentes.

## Features e métodos

`adoption-governance` e `governance-externalization` são históricas.
As nove features `skill-*` validam a autoria e a seleção da biblioteca,
não o funcionamento de módulos do produto.

Features do aplicativo usam prefixo `product-*`, permanecem diretamente
em `sdd/features/` e possuem requisitos, oráculos, evidências e estados
independentes dos SDDs das skills. A rota local segue `sdd/workflow.md`;
não abrir feature completa apenas para cumprir formalidade.

As 29 skills e 29 pontes continuam disponíveis conforme o perfil versionado.
Uma competência primária é selecionada somente quando pertinente;
auxiliares exigem perguntas técnicas distintas. Disponibilidade,
seleção, consulta e uso não são equivalentes.

## Stack e situação técnica

Decidido para o código próprio do produto: Rust e Iced, com proibição de
`unsafe` próprio conforme `POL-01`. O armazenamento controlado pelo Ox será
local no MVP; LSP e capacidades avançadas serão integrados por plugins.

**Estado observado no pacote-base de 26/10/2026:** nenhum `Cargo.toml`,
lockfile ou crate de produto estava presente. Esta afirmação descreve a
baseline e **deverá ser atualizada** quando a primeira entrega Rust existir.
Não são declarados MSRV, versão Iced, runtime assíncrono ou plataformas
alvo enquanto suas ADRs não forem aprovadas.

Ferramentas de governança atuais: Python 3.11+ e stdlib. O SDD 1.3.0 e
seu validador original permanecem preservados; essas ferramentas não são
o código Rust do aplicativo.

## Comandos disponíveis — governança

Da raiz Ox, enquanto esses scripts existirem:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 sdd/tools/validate.py --root .
PYTHONDONTWRITEBYTECODE=1 python3 sdd/tools/validate.py --root . --structure-only
PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/check-ox.py
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s src/tests -v
PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/run-checks.py
```

Comandos Cargo, testes de integração Rust, benchmarks e instaladores
somente serão adicionados **após** existirem fontes e configurações reais.
Nenhuma saída dos comandos Python valida o aplicativo Rust/Iced.

## Decisões pendentes e limites

Consultar `docs/decisions/open-questions.md` antes de selecionar plataforma,
versões, runtime, IPC, banco, sandbox, agentes ou distribuição.
Autorização de feature não substitui política de risco e permissões efetivas.
Não solicitar `--require-approved` global enquanto houver critérios técnicos
intencionalmente NÃO VERIFICADO.

## Histórico da biblioteca

O catálogo ativo está em `.codex/skills/`. As 29 pontes usam essa localização.
Registros históricos em `docs/validation/` preservam caminhos, hashes e limites
anteriores; não são fontes do estado atual do aplicativo. Os três estudos
externos não pertencem à distribuição nem ao processo de validação.
````

**Nota de implementação:** o bloco acima é Markdown de substituição; os comandos `bash` devem aparecer em cercas de código próprias no arquivo final, com a sintaxe preservada. O campo `implementation-foundation` é uma **convenção textual proposta**, não um campo formal do schema SDD 1.3.0. Não adicionar front matter inventado ao verificador.

**Aceite:** a fase está explícita, o produto continua não validado, as nove features de skill permanecem independentes e não há autorização implícita de operações externas.

---

## 5. Alteração P0 — `README.md`

### 5.1 Título atual

```markdown
# Ox — governança e biblioteca
```

**Novo valor:**

```markdown
# Ox — plataforma agent-first (em implementação)
```

### 5.2 Parágrafo de abertura atual

> Distribuição autocontida: este repositório contém governança operacional e biblioteca de skills. [...] O aplicativo Rust/Iced ainda não foi implementado.

**Substituir por:**

```markdown
**Estado do repositório:** a fundação do aplicativo Ox está em fase de
implementação por features SDD. O pacote-base auditado continha governança,
29 skills e 29 pontes; ainda não possuía um aplicativo executável.
A existência de uma feature autorizada não representa implementação aprovada.

**Autoridades:** [constituição](docs/constitution.md),
[AGENTS.md](AGENTS.md), [contexto SDD](sdd/project.md),
[workflow](sdd/workflow.md) e [ADRs](docs/decisions/).

**Documentos externos:** os três estudos de planejamento permanecem fora
do repositório, da distribuição e das dependências dos validadores.
```

### 5.3 Separar testes de governança dos testes de produto

Manter os comandos Python existentes na seção **“Verificação da governança e skills”**. Acrescentar abaixo:

```markdown
## Verificação do aplicativo

A validação do aplicativo Rust/Iced será definida nas features `product-*`
e nos respectivos testes/CI quando os componentes forem implementados.
Os comandos SDD/Python acima validam documentos, pontes, perfis e invariantes
de governança; **não** comprovam compilação, segurança ou funcionamento
do aplicativo.

Não executar nem divulgar comandos Cargo como testes aprovados antes de
existirem `Cargo.toml`, fontes e ferramentas configuradas.
```

### 5.4 Empacotamento atual

A frase atual que apresenta o empacotador como gerador de um “ZIP” deve **dizer explicitamente**:

```markdown
## Pacote de governança (não é release do aplicativo)

`src/scripts/package-ox.py` distribui e qualifica apenas a biblioteca de
skills, os contratos SDD, a governança e seus testes. A allowlist desse
empacotador **não inclui** `Cargo.toml`, `crates/`, binários ou instaladores.
O aplicativo Ox deverá possuir pipeline de build, testes e distribuição
separado, com manifestos e evidências próprios.
```

Manter as seções de histórico como histórico. Não transformar a anterior validação de governança em “aplicativo aprovado”.

---

## 6. Alteração P0 — `docs/constitution.md`

**Preservar integralmente:** `POL-01` a `POL-10`, `GOV-01` a `GOV-05` e `GOV-08`, salvo erro factual descoberto em revisão independente. `GOV-06` e `GOV-07` contêm termos temporais que devem deixar de tratar a implementação como eternamente futura. **Não criar políticas duplicadas no `AGENTS.md`.**

### 6.1 `GOV-06` — substituir linha completa

**Novo valor proposto:**

```markdown
- GOV-06: Features de autoria de skills e features de produto `product-*` têm critérios e evidências independentes. Cenários técnicos sem implementação ou verificação efetiva permanecem NÃO VERIFICADO; estrutura, respostas textuais e uma skill aprovada não provam funcionamento do aplicativo. Cada feature do produto exige aceitação vinculada ao estado real de seus inputs.
```

### 6.2 `GOV-07` — substituir linha completa

**Novo valor proposto:**

```markdown
- GOV-07: Somente decisões expressas em autoridades locais são vigentes. Rust/Iced, unsafe próprio proibido, fluxo agent-first, persistência local, extensibilidade, LSP por plugins, dois modos de grafo e motores próprios de contexto/grafo/compactação estão adotados como direção de produto. Runtime, banco, IPC, parsers, versões, plataformas, licença e sandbox aguardam ADRs. O desenvolvimento do aplicativo poderá ocorrer somente no escopo de features autorizadas conforme `sdd/project.md` e `sdd/workflow.md`; autorização de desenvolvimento não significa validação, publicação ou permissão irrestrita.
```

**Importante:** não acrescentar novo ID apenas para mudar fase. `GOV-07` registra o contrato de autorização e remete ao SDD, evitando incorporar regras de execução na constituição. Se a equipe julgar que a fase é puramente operacional, alternativa igualmente válida é **não mudar GOV-07**, desde que se retire apenas a frase temporal e se preserve integralmente sua semântica. A opção acima é proposta por ser mais explícita e testável.

---

## 7. Alteração P0 — `src/fixtures/normative-coverage.json`

O verificador `src/scripts/check-ox.py` extrai os textos das regras `POL-*`/`GOV-*` e compara seus SHA-256 com `rule_sha256` no JSON. Portanto, **qualquer mudança no texto de `GOV-06` e `GOV-07` exige atualizar somente os hashes correspondentes**, mediante revisão de autoridade.

**Manter para ambas:**

```json
{
  "authority": "docs/constitution.md",
  "method": "Revisão de contrato local e testes de governança; produto futuro não verificado",
  "oracle": "src/tests/test_governance.py",
  "scope": "governance-contract; not product implementation"
}
```

A frase `produto futuro não verificado` em `method` deverá ser ajustada **para os dois IDs alterados** a:

```json
"method": "Revisão de contrato e fase local; funcionamento do produto não verificado"
```

**Novo valor dos hashes:** derivar dos bytes **efetivamente salvos e aprovados**, nunca copiar hashes fictícios deste documento. Procedimento reproduzível:

```bash
python3 - <<'PY'
import hashlib, json, pathlib, re
root = pathlib.Path('.')
source = (root/'docs/constitution.md').read_text(encoding='utf-8')
p = root/'src/fixtures/normative-coverage.json'
coverage = json.loads(p.read_text(encoding='utf-8'))
for key in ('GOV-06', 'GOV-07'):
    found = re.findall(r'^- '+re.escape(key)+r': (.+)$', source, re.M)
    assert len(found) == 1, (key, found)
    coverage[key]['rule_sha256'] = hashlib.sha256(found[0].encode()).hexdigest()
    coverage[key]['method'] = ('Revisão de contrato e fase local; '
                               'funcionamento do produto não verificado')
p.write_text(json.dumps(coverage, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
PY
```

Executar **somente depois** da edição aprovada em `docs/constitution.md` e registrar a revisão e a validação dessa cobertura. Atualizar hashes de contrato **não** equivale a renovar hashes de evidências anteriores nem a comprovar funcionamento do produto.

---

## 8. Alteração P0 — `docs/decisions/open-questions.md`

### 8.1 Texto inicial

**Atual:**

> Nenhuma destas decisões é indispensável à autoria local desta biblioteca. Antes de implementar o consumidor, registrar uma ADR por decisão material [...] .

**Novo valor:**

```markdown
As decisões listadas continuam abertas durante a implementação da fundação do
Ox. Antes de adotar uma tecnologia ou ação cujo risco dependa dessas escolhas,
registrar a ADR correspondente, suas alternativas, limitações e critérios.
A abertura da fase de implementação não aprova automaticamente itens PENDENTE,
PROPOSTA ou HIPÓTESE.
```

### 8.2 `OPEN-10` — mudar **somente a coluna “Retomada”**

**Novo valor da linha:**

```markdown
| OPEN-10 | HIPÓTESE | Embeddings, nuvem opt-in, marketplace e economia de tokens | Avaliação comparativa futura; fora do escopo inicial de `product-foundation`, salvo decisão SDD posterior explícita |
```

### 8.3 Última frase

**Atual:** “Propostas não autorizam instalar dependências, executar agentes externos, transmitir código, gastar, publicar ou implementar o aplicativo nesta tarefa.”

**Novo valor:**

```markdown
Uma proposta ainda não aprovada não concede permissões. A implementação local
do produto exige feature e escopo autorizados; dependências, agentes externos,
transmissão de código, gastos, operações destrutivas e publicação continuam
sujeitos às permissões efetivas e às decisões aplicáveis.
```

**Manter** `OPEN-01` a `OPEN-09` e `OPEN-11` sem mudar seus estados nesta transição; plataformas, versões, IPC, sandbox e licenças **continuam pendentes**.

---

## 9. Alteração P1 — `docs/architecture/context.md`

A arquitetura já distingue **previsto** de **implementado** corretamente. O risco é que a frase “Nenhum desses componentes está implementado neste pacote” fique obsoleta assim que um crate real surgir.

### 9.1 Novo valor para a frase final do terceiro parágrafo

```markdown
O estado de implementação deverá ser acompanhado nas features `product-*`
e em seus artefatos de verificação. A baseline de governança não contém
implementação desses componentes; sua presença futura só poderá ser declarada
após inspeção do código e das evidências atuais.
```

### 9.2 Novo valor para a frase final do documento

```markdown
A preparação das skills P0/P1 foi registrada historicamente e não altera
a ordem dos marcos do produto. Na fase `implementation-foundation`, somente
features `product-*` e evidências próprias demonstram entregas do aplicativo.
Persistência, avaliação de agentes e distribuição continuam abrangidas pelas
competências existentes quando pertinentes.
```

**Manter** o mapa F0–F8 e os contratos de responsabilidade. **Não** marcar F0 como concluído sem critérios/execuções correspondentes.

---

## 10. Alteração P1 — `docs/security/trust-boundaries.md`

O conteúdo da tabela é correto como diagnóstico da baseline. Para evitar estados permanentes falsamente negativos/positivos, mudar o título da coluna **“Estado atual”** para **“Estado verificado na baseline / atualização”** e acrescentar após a tabela:

```markdown
Os estados acima referem-se à baseline de governança. Cada controle de produto
somente poderá mudar de NÃO VERIFICADO mediante evidência de integração
ou teste adversarial do componente e plataforma correspondente, vinculada
à feature `product-*` e ao snapshot real. Autorizar desenvolvimento
não equivale a demonstrar sandbox, isolamento ou segurança do runtime.
```

Não substituir `NÃO VERIFICADO` por `APROVADO` e não apagar limitações de sandbox nativo.

---

## 11. Alteração P1 — `sdd/features/README.md`

**Substituir integralmente por:**

```markdown
# Índice das features SDD do Ox

As features desta pasta são independentes e permanecem diretamente em
`sdd/features/` conforme o validador SDD 1.3.0 adotado.

## Governança histórica

- `adoption-governance`: adoção da biblioteca e autoridades.
- `governance-externalization`: retirada de dependências de estudos externos.

Os resultados históricos não são substituídos pela abertura da fase de produto.

## Biblioteca de skills

- `skill-*`: autoria, roteamento e avaliação das nove especializações.
- Critérios técnicos que exigem subsistemas reais continuam NÃO VERIFICADO
  quando não há evidência de implementação.

## Produto Ox

- `product-foundation`: transição de fase e preparação verificável da fundação.
- Futuras `product-*`: módulos Rust/Iced, plugins, runtime, contexto,
  grafos, verificação e demais capacidades, cada uma com evidências próprias.

A rota local segue `sdd/workflow.md`. Não mover features para escapar dos gates,
não promover aprovações históricas e não confundir documentação com implementação.
```

Incluir a entrada `product-foundation` **somente quando a pasta realmente tiver sido criada**, ou marcá-la explicitamente como planejada enquanto ausente.

---

## 12. Empacotamento e verificação: não confundir dois produtos

### 12.1 Problema observado

`src/scripts/governance_support.py` usa:

```python
ROOT_FILES = ('AGENTS.md', 'README.md')
ROOT_DIRS = ('.codex/skills', 'sdd', 'src', 'docs')
```

`src/scripts/package-ox.py` consome essa allowlist e gera `ox-corrigido.zip` em `dist/`. **Esse arquivo não conterá automaticamente `Cargo.toml`, `Cargo.lock`, `crates/`, `plugins/` ou binários criados após a transição.** O ZIP pode continuar passando integralmente nos testes de governança e, mesmo assim, **não representar o aplicativo**.

### 12.2 Correção exigida — escopo do pacote

1. **Não** ampliar automaticamente `ROOT_DIRS` para incluir o workspace de código: isso faria `run-checks.py` e a inspeção recursiva processarem `target/`, artefatos temporários, fixtures grandes, binários e outras entradas fora do contrato de governança.
2. Manter `distribution_files()` como inventário do **pacote de governança**, com comentário/docstring explícitos.
3. Em `src/scripts/package-ox.py`, trocar:

```python
package = output/'ox-corrigido.zip'
```

por:

```python
package = output/'ox-governance.zip'
```

4. Alterar a mensagem e o campo de limites do recibo (`results.json`) para os valores:

```python
'package_kind': 'governance',
'product_included': False,
'limitations': [
    'Validation covers governance/skills/SDD, not the Ox Rust application.',
    'Cargo workspace, binaries, installers and product integration tests are out of this package.'
]
```

5. Quando o primeiro crate existir, criar **separadamente** um pipeline de distribuição do aplicativo, que deverá incluir fontes/artefatos aplicáveis, lockfile, componentes do produto, licença, SBOM, verificações Cargo e testes de instalação. **Não declarar esse pipeline implementado nesta transição**.
6. Acrescentar teste que verifica que a allowlist de governança não é apresentada como pacote do aplicativo; teste de produção separado deverá rejeitar release sem binário/instalador ou manifesto correspondente.

**Opcional:** renomear `package-ox.py` para `package-governance.py` somente em mudança controlada com atualização de README, testes e logs de comandos vigentes. Para reduzir risco agora, é preferível manter o caminho do script e mudar seu rótulo/saída.

### 12.3 `src/scripts/check-ox.py`

Manter os checks existentes de perfil, cópias históricas, pontes, critérios e hashes. **Não eliminar** este trecho:

```python
if criterion['id'] in {'AC-01','AC-02','AC-03','AC-04'} and criterion['status'] != 'NÃO VERIFICADO':
    errors.append('Technical scenario promoted without authorized product review: '+name+': '+criterion['id'])
```

Esse gate pertence aos SDDs de autoria das skills, **não aos critérios das futuras features `product-*`**. O produto poderá aprovar testes reais próprios sem falsificar os 36 cenários históricos das skills.

**Acrescentar um check de consistência de fase**, limitado às autoridades correntes:

- `sdd/project.md` registra `implementation-foundation`;
- `AGENTS.md` não contém a proibição antiga “O escopo atual é governança e biblioteca: não implementar ...”;
- `README.md` distingue pacote de governança e aplicativo;
- `docs/constitution.md` não contradiz a autorização por feature;
- nenhuma política, perfil de skills ou evidência de produto é aprovada apenas com essa transição.

Não verificar o estado procurando uma frase solta em qualquer Markdown histórico: testes assim rejeitariam arquivos legítimos de auditoria.

### 12.4 `src/scripts/run-checks.py`

Manter a suíte Python existente. No relatório novo, renomear o escopo de saída de “verificação do Ox” para **“verificação da governança/SDD do Ox”** e preservar a ressalva:

```python
'limitations': [
    'Governance, SDD and skill-contract checks only.',
    'No Rust compilation, application integration, sandbox effectiveness or product acceptance is established.'
]
```

Se um wrapper de CI futuro executar ambos, apresentar **dois resultados independentes**: `governance_checks` e `product_checks`.

### 12.5 `src/tests/test_governance.py` — casos novos

Acrescentar **sem remover nenhum dos 13 testes existentes**:

| Novo teste | Condição de sucesso | Falha que deve detectar |
|---|---|---|
| `test_implementation_phase_consistency` | `AGENTS.md`, project, constitution e README possuem papéis coerentes | Proibição antiga mantida em instrução operacional vigente |
| `test_governance_package_not_product_release` | Artefato rotulado governance e `product_included=false` | ZIP validado como se contivesse a IDE |
| `test_product_feature_isolated_from_skill_acceptance` | Feature `product-*` não altera os 36 estados de skill | Falsa promoção de aceitação técnica |
| `test_normative_hash_requires_review` | Mutar `GOV-07` sem atualizar cobertura reprova | Contrato alterado sem revisão correspondente |
| `test_historical_files_remain_immutable` | ADRs/relatórios antigos mantêm seus hashes | Falsificação retrospectiva da migração |

**Importante:** dois testes com mesmo resultado não bastam se compartilharem o mesmo oráculo incorreto. Combinar verificações de conteúdo, mutações intencionais, aceitação SDD e revisão dos resultados observados.

---

## 13. ADR nova — `docs/decisions/implementation-transition.md`

**Criar com o seguinte texto inicial:**

```markdown
# ADR — Transição de governança para implementação do produto Ox

Estado: proposta em execução; a aceitação requer a feature
`sdd/features/product-foundation/` e evidências próprias.

## Contexto

A fase de governança e biblioteca foi preparada e validada em escopo
restrito. `AGENTS.md` e `sdd/project.md` ainda proíbem genericamente
implementar o aplicativo. O mantenedor decidiu iniciar a fundação Rust/Iced
sob SDD, preservando a separação entre autoridades e verificações.

## Decisão

- A fase operacional passa a `implementation-foundation` em `sdd/project.md`.
- O `AGENTS.md` torna-se somente ponto de entrada e orientação.
- Políticas permanentes continuam em `docs/constitution.md`.
- Cada funcionalidade do Ox será conduzida por rota SDD proporcional
  ao risco, com evidências separadas das features `skill-*`.
- O pacote Python atual é de governança, não uma distribuição do aplicativo.
- Não são aprovados automaticamente runtime, IPC, banco, SO, sandbox,
  dependências, gastos, publicação, acesso externo ou nuvem.

## Alternativas consideradas

1. Repetir as regras SDD e Rust/Iced integralmente em `AGENTS.md`:
   rejeitada por duplicar autoridades.
2. Manter indefinidamente a proibição de implementação:
   rejeitada por bloquear a fase agora desejada.
3. Promover a governança antiga a aceitação de produto:
   rejeitada por ausência de implementação/evidência de software.

## Consequências e gates

Novas features `product-*` precisarão de critérios de aceitação,
revisão de riscos, testes efetivos e snapshots atuais. Histórico e
36 cenários técnicos não verificados da biblioteca permanecem intactos.

## Reavaliar quando

Houver mudança nas fronteiras de permissões, nos contratos de plugins,
no processo SDD, nas plataformas alvo ou na política de distribuição.
```

Ao concluir a migração e seus testes, substituir `Estado: proposta em execução` por `Estado: adotada em <data observada>`, mantendo o histórico da decisão. **Não marcar adotada antecipadamente.**

---

## 14. Feature SDD de transição — `sdd/features/product-foundation/`

Esta é uma mudança de **escopo operacional e contrato de desenvolvimento**; portanto, a **rota completa** é adequada. Uma única feature deve documentar a transição, enquanto implementações reais futuras podem ter suas próprias features para UI, Plugin Host, Agent Runtime etc.

### 14.1 `spec.md` — valores propostos

```markdown
# Fundação do produto Ox — transição de fase

Ator: mantenedor e agentes de desenvolvimento autorizados.
Objetivo: permitir desenvolvimento do aplicativo via SDD sem duplicar
políticas no AGENTS e sem alegar implementação inexistente.

- REQ-01: Registrar fase de implementação e seu escopo na autoridade SDD.
- REQ-02: Manter AGENTS como entrada operacional, sem políticas duplicadas.
- REQ-03: Separar evidências das features do produto e da biblioteca.
- REQ-04: Diferenciar distribuição da governança de distribuição do aplicativo.
- REQ-05: Preservar decisões, arquivos e evidências históricas sem falsificação.

- AC-01 → REQ-01: `sdd/project.md` declara a fase `implementation-foundation`, sem concessão irrestrita de permissões.
- AC-02 → REQ-02: `AGENTS.md` não impede genericamente implementar o produto e remete aos contratos SDD e à constituição.
- AC-03 → REQ-03: Uma feature `product-*` possui critérios próprios; os 36 cenários técnicos das nove features de skill permanecem NÃO VERIFICADO.
- AC-04 → REQ-04: O pacote atual é identificado e verificado como governança; não é anunciado como aplicativo compilado.
- AC-05 → REQ-05: As autoridades atuais passam nos verificadores; os registros históricos conservam seus conteúdos e aprovações originais.

Rejeitar: aprovar software não implementado, alterar evidência antiga,
importar estudos externos, autorizar publicação ou executar ações sem grant.
```

### 14.2 `plan.md` — decisões/riscos iniciais

```markdown
# Plano — fundação do produto Ox

Rota: completa (mudança de escopo e de contratos operacionais).

| ID | Decisão / risco | Relação |
|---|---|---|
| D-01 | Fase em sdd/project.md, entrada operacional em AGENTS.md | REQ-01, REQ-02 |
| D-02 | Manter estados e evidências de produto separados das skills | REQ-03, REQ-05 |
| D-03 | Distribuição de governança não equivale a release Rust | REQ-04 |
| R-01 | Autorização genérica interpretada como execução irrestrita | REQ-01, REQ-02 |
| R-02 | Aprovação de skills apresentada como qualidade do aplicativo | REQ-03, REQ-05 |
| R-03 | Empacotador ignora Cargo.toml e crates/ mas entrega ZIP “aprovado” | REQ-04 |

Seleção de skills: registrar após consultar entradas reais.
Candidata principal: software-evolution, para migração de contratos.
Candidatas auxiliares, se a questão justificar: software-architecture,
software-testing e technical-documentation.
Não declarar skills “utilizadas” só por constarem neste plano.
```

### 14.3 `tasks.md` — sequência

```markdown
# Tarefas — transição de fase

- [ ] T001 [REQ-01, REQ-02, D-01, R-01]: revisar autoridades e preservar baseline antes das edições.
- [ ] T002 [REQ-01, REQ-02, D-01, R-01]: atualizar AGENTS, sdd/project, README e ADR de transição.
- [ ] T003 [REQ-02, REQ-05, D-01, R-02]: atualizar GOV-06/GOV-07 e cobertura por hash, sob revisão explícita.
- [ ] T004 [REQ-03, D-02, R-02]: separar índice de features de produto/skills sem alterar 36 pendências.
- [ ] T005 [REQ-04, D-03, R-03]: corrigir rotulagem do pacote e adicionar teste adversarial.
- [ ] T006 [REQ-05, D-02, R-02]: executar validação SDD, check-ox e suíte Python; registrar evidências novas.
- [ ] T007 [REQ-01..REQ-05]: revisar convergência e desbloquear apenas a feature de produto efetivamente autorizada.
```

### 14.4 `converge.md` — estado inicial correto

```markdown
# Convergência — product-foundation

| Critério | Estado | Evidência |
|---|---|---|
| AC-01 | NÃO VERIFICADO | Nenhum check realizado nesta nova revisão |
| AC-02 | NÃO VERIFICADO | Nenhum check realizado nesta nova revisão |
| AC-03 | NÃO VERIFICADO | Nenhum check realizado nesta nova revisão |
| AC-04 | NÃO VERIFICADO | Nenhum check realizado nesta nova revisão |
| AC-05 | NÃO VERIFICADO | Nenhum check realizado nesta nova revisão |

Atualizar somente após observar método, artefatos e inputs reais.
```

### 14.5 `traceability.json` e `evidence.json`

- Criar `traceability.json` com **uma entrada por AC** apontando para IDs `REQ`, `D`, `R`, `T` existentes e para arquivos de implementação/oráculo **reais**. Exemplos de candidatos: `AGENTS.md`, `sdd/project.md`, `docs/constitution.md`, `src/scripts/package-ox.py`, `src/tests/test_governance.py`.
- Criar `evidence.json` no **schema 2** conforme `sdd/evidence.md`, inicialmente com os cinco critérios `NÃO VERIFICADO` e a lista `evidence` vazia. Não inventar artefatos, comandos executados nem hashes.
- Ao executar verificações, preencher os registros com ambiente, resultado, método, arquivo de saída e hashes dos **inputs realmente observados**, incluindo os contratos relevantes da feature.
- A primeira execução deverá ser `--structure-only`; só solicitar aprovação da feature depois de reunir provas. A aceitação global `--require-approved` permanecerá imprópria enquanto os 36 cenários técnicos intencionalmente pendentes continuarem no catálogo.

### 14.6 `checklist.md`

**Opcional.** Se usada, revisar: ausência de regras duplicadas no `AGENTS.md`, preservação de autoridade constitucional, contexto de fase correto, não promoção de critérios das skills e empacotamento honestamente rotulado. Marcar a checklist não prova que o software foi testado.

---

## 15. Testes e comandos de aceitação

### 15.1 Ordem de execução após a aplicação real

```bash
# 1. Verificar estrutura e rastreabilidade, inclusive nova feature em andamento.
PYTHONDONTWRITEBYTECODE=1 python3 sdd/tools/validate.py --root . --structure-only

# 2. Verificar contratos e links locais.
PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/check-ox.py

# 3. Executar todos os testes Python existentes e os casos novos.
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s src/tests -v

# 4. Registrar uma rodada nova e verificável.
PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/run-checks.py

# 5. Verificar freshness das evidências decididas.
PYTHONDONTWRITEBYTECODE=1 python3 sdd/tools/validate.py --root . --require-fresh

# 6. Qualificar em extração limpa APENAS o pacote de governança.
PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/package-ox.py
```

**Não executar `cargo test`, `cargo build` ou `cargo clippy` como gates de produto** até existir Cargo workspace efetivo e a ferramenta estar disponível. Depois, exigir esses testes separadamente na feature Rust correspondente.

### 15.2 Critérios de aprovação da transição

- [ ] `AGENTS.md` é somente entrada operacional; não repete a constituição ou o SDD completo.
- [ ] `sdd/project.md` identifica fase, escopo autorizado e estado real do aplicativo.
- [ ] `docs/constitution.md` conserva as políticas e não contém proibição temporal incompatível.
- [ ] Hashes dos únicos IDs normativos modificados correspondem aos textos aprovados.
- [ ] O modelo original `sdd/workflow.md`, `sdd/evidence.md`, templates e verificador continuam preservados.
- [ ] As 29 skills e 29 pontes continuam íntegras.
- [ ] Os 36 critérios técnicos das skills permanecem `NÃO VERIFICADO`.
- [ ] Os três estudos externos continuam ausentes e dispensáveis.
- [ ] O ZIP de governança declara explicitamente que **não é pacote do aplicativo**.
- [ ] Nenhuma ADR histórica, hash antigo ou evidência velha foi sobrescrita.
- [ ] Tests adversariais falham com contrato/escopo alterado indevidamente e passam após restauração.
- [ ] As validações aplicáveis passam em extração independente.
- [ ] A feature `product-foundation` registra ACs, decisões, tarefas e evidências novas sem inventar execuções.

---

## 16. Preservação histórica e atualização de evidências

**Não alterar nem “corrigir” retroativamente:**

- `docs/decisions/adoption.md`;
- `docs/decisions/governance-externalization.md`;
- `docs/validation/report.md` (relatório de escopo antigo);
- `docs/validation/governance-externalization/**`;
- `docs/validation/adoption-baseline/**`;
- `docs/validation/agent-evals/**`;
- `sdd/features/adoption-governance/**`;
- `sdd/features/governance-externalization/**`;
- avaliações e snapshots das nove features `skill-*` não afetadas.

**Criar** `docs/validation/implementation-transition/summary.md` com o resultado **observado** da transição, os comandos exatos, ambiente, snapshots, hashes dos arquivos revisados, conflitos e limites. Manter falhas da primeira tentativa no registro, mesmo que a execução posterior passe.

O mecanismo SDD schema 2 vincula observações a seus inputs: se um input efetivamente utilizado mudar, reexecutar ou reexaminar **apenas as evidências afetadas**; não reescrever seus hashes para fazê-las parecer atuais. Uma evidência histórica válida para a versão antiga pode permanecer como história, sem autorizar o estado novo.

---

## 17. Limites desta transição e decisões que continuam abertas

| Assunto | Continua pendente? | Próximo gatilho |
|---|---|---|
| Sistemas operacionais suportados | Sim | ADR antes de matriz CI/release |
| Versões de Rust/Iced e MSRV | Sim | Primeiro Cargo workspace |
| Runtime assíncrono (Tokio ou alternativa) | Sim | Feature de Agent Runtime |
| IPC e contrato de plugins | Sim | Feature de Plugin Host |
| Implementação real do sandbox | Sim | Testes por SO, sem presumir isolamento por processo |
| SQLite e esquema local | Sim | Feature de persistência |
| Agentes CLI e ACP suportados | Sim | Protótipo com capabilities reais |
| LSP sob demanda | Definido como conceito; implementação pendente | Plugin específico |
| Testes e critérios da GUI Iced | Pendentes | Spike Iced + integração |
| Plataforma comercial/licença | Sim | Antes de distribuição/SDK público |
| Nuvem paga | Fora do MVP | Nova ADR opt-in no futuro |

**Não fazer nesta transição:** criar componentes Rust fictícios, conceder acesso a rede, instalar agentes ou dependências sem escopo autorizado, aprovar sandbox por documentação, modificar regras de skills, apagar cenários `NÃO VERIFICADO` ou adicionar os três estudos externos à distribuição.

---

## 18. Fluxo Mermaid — autoridades e transição

```mermaid
flowchart TD
    U[Pedido autorizado de iniciar implementação] --> S[SDD: product-foundation]
    A[AGENTS.md: entrada operacional] --> P[sdd/project.md: fase e escopo]
    A --> C[docs/constitution.md: políticas]
    P --> S
    C --> S
    S --> SP[spec.md: critérios]
    SP --> PL[plan.md: ADRs e skills pertinentes]
    PL --> T[tasks.md: alterações e testes]
    T --> V[Executar checks e coletar evidências]
    V --> G{Aceites sustentados?}
    G -->|Não| N[Registrar pendências / corrigir]
    N --> T
    G -->|Sim| CV[converge.md: resultado da transição]
    CV --> F[Primeira feature de produto Rust/Iced]
    F --> I[CI e evidências de aplicativo separadas]
```

```mermaid
flowchart LR
    B[Pacote atual: governança] --> C[Skills e SDD]
    C --> D[Testes Python e hashes de governança]
    X[Cargo workspace do produto] --> E[Build e testes Rust]
    E --> R[Distribuição futura do aplicativo]
    D -. nao valida .-> R
    C -. fornece instrucoes .-> E
```

---

## 19. Ordem operacional recomendada

1. Preservar baseline do ZIP atualizado e calcular hashes dos arquivos que serão modificados.
2. Abrir `product-foundation` na rota SDD completa e registrar ADR de transição em estado **proposta**.
3. Atualizar `sdd/project.md` e `AGENTS.md`; depois README e documentos de estado.
4. Atualizar apenas cláusulas temporais `GOV-06`/`GOV-07` e a cobertura dos seus hashes, após revisão.
5. Identificar oficialmente `package-ox.py` como distribuidor de governança; acrescentar testes adversariais de fase/escopo.
6. Executar verificações estruturais, suite Python e qualificação em cópia independente.
7. Gerar **nova** evidência da transição; resolver falhas; aprovar critérios **da transição** segundo o SDD.
8. Marcar ADR como adotada somente após a aprovação pertinente.
9. Iniciar **uma feature de produto específica** (`product-iced-shell`, `product-plugin-host`, etc.), decidindo versões/risco pelo seu próprio SDD. Não apresentar essa nova fase como implementação já concluída.

### Veredito

**A correção exigida é uma transição de autoridade operacional, não uma reescrita do SDD nem da biblioteca de skills.** O principal erro a evitar seria transferir a constituição para `AGENTS.md` ou transformar a aprovação de governança em aprovação de software. O segundo é passar a distribuir um pacote chamado Ox que, na prática, não inclui o código Rust. Com as alterações acima, o projeto poderá iniciar a implementação sem perder suas fronteiras de responsabilidade, rastreabilidade e confiabilidade.
