# Convergência inicial

AC-01..06: NÃO VERIFICADO. Autoria materializada; avaliação e integração têm critérios separados. Retomar T003 para revisão/casos e T004 somente em consumidor autorizado.
