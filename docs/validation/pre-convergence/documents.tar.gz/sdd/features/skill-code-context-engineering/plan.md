# Plano de autoria de code-context-engineering

Rota completa por contrato de competência, fronteiras e critérios de avaliação. Autoridade: spec desta feature e constituição do consumidor para efeitos autorizados.

## Alternativas técnicas preservadas

As escolhas abaixo são alternativas de método a ensinar/avaliar, não decisões técnicas aprovadas do Ox.


| ID | Decisão ou risco | Verificação proposta |

|---|---|---|

| D-01 | Índice de caminhos/texto sempre útil, parser incremental por linguagem e LSP somente quando justificado. | Revisão de alternativas + contrato observado |

| D-02 | Snapshot/offset/proveniência explícitos e ranking controlado por recall/precisão/custo. | Cenários rejeitados e comparação de opções |

| R-01 | Índice obsoleto; respostas da IA com posições incorretas. | Teste adverso pertinente |

| R-02 | Indexação excessiva na abertura e alto consumo de recursos. | Falsificação controlada do resultado |



D-03 [REQ-04]: criar entrada, três referências especializadas e casos próprios em vez de duplicar uma skill geral; custo de manutenção justificado pelas seções 6 e 8 do comparativo. R-03 [REQ-04]: seleção ambígua ou texto superficial; verificar com casos positivos, negativos e falha. Reavaliar após uso observado ou mudança das fontes.

## Seleção de métodos e dependências

Método primário de autoria efetivamente consultado: skill-creator do ambiente (versão não declarada; cópia de consulta em docs/validation/adoption-baseline/skill-creator.md). Sem ponte local para esse método. Esta nova skill não existia na seleção inicial e não é declarada consultada na própria autoria.

A ponte sdd/chain/code-context-engineering.md, bridge_version 1, e entrada skills/code-context-engineering/SKILL.md ficam disponíveis para consumidores e avaliação posterior; existência não prova consulta. Auxiliar condicional proposta: `ai-engineering` — A recuperação realmente eleva a taxa de sucesso da tarefa em relação a uma busca simples? Sem consulta automática.

Dependências de autoria: protocolo → runtime → verificação; workspace/Iced completam fundação; contexto antecede grafo; output e uso dependem do vocabulário de eventos. Não são dependências de instalação.

## Atividades técnicas propostas a ensinar e retomar

> - [ ] P001 [REQ, AC, D, R aplicáveis]: Modelar identidade de símbolo, documento, hash e versão do índice.
> - [ ] P002 [REQ, AC, D, R aplicáveis]: Prototipar extração, busca e invalidação em fixtures multilíngues.
> - [ ] P003 [REQ, AC, D, R aplicáveis]: Definir integração opcional LSP e semântica de evidência.
> - [ ] P004 [REQ, AC, D, R aplicáveis]: Executar avaliações recall/latência/freshness e documentar limites.

P001..P004 preservam a intenção das tarefas propostas; não declaram implementação do produto. A execução local de autoria está em tasks.md. Testes reais dependem de consumidor e escopo autorizado.
