# Convergência em andamento

AC-01 a AC-04: NÃO VERIFICADO. Retomar após T004 e inspeção final.
