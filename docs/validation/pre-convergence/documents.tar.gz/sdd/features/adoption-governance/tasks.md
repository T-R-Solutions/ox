# Tarefas da adoção

- [ ] T001 [REQ-01, AC-01, D-01, R-01]: capturar baseline, inventário e cópias com hashes; arquivos docs/structure e docs/validation; sem dependências.
- [ ] T002 [REQ-02, AC-02, D-02, R-02]: autorar nove skills, recursos e 29 pontes; depende T001; concluir após revisão de fronteiras e auditoria.
- [ ] T003 [REQ-03, AC-03, D-03, R-03]: registrar constituição, AGENTS, projeto, nove features e cobertura normativa; depende T001.
- [ ] T004 [REQ-04, AC-04, D-04, R-04]: executar validação copiada, testes locais e avaliações autorizadas; depende T002/T003; preservar cada rodada.
- [ ] T005 [REQ-01, REQ-03, AC-01, AC-03, D-01, R-01]: inspecionar diff, append de revisões, hashes e convergência final; depende T004.
