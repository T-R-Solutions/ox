# Ox — governança e biblioteca

Preparação local concluída em artefatos; o aplicativo Ox não foi implementado. Preserve os três documentos originais na raiz. A [constituição](docs/constitution.md) é a única autoridade de políticas permanentes; [AGENTS.md](AGENTS.md) orienta agentes.

## Navegação

- [Contexto SDD e comandos](sdd/project.md), [workflow 1.3.0](sdd/workflow.md) e [evidências/schema 2](sdd/evidence.md).
- [Catálogo](skills/README.md): **29 skills** — 17 gerais copiadas, 3 condicionais copiadas, 5 novas P0 e 4 novas P1. As 20 existentes mantêm recursos e bytes de origem.
- [29 pontes](sdd/chain/README.md): 20 adaptadas e 9 novas, com paths relativos e identidade verificável.
- [Features](sdd/features/README.md): adoção de governança e nove SDDs `skill-*`, separados de futuras funcionalidades `product-*`.
- [Arquitetura e fases](docs/architecture/context.md), [decisões da adoção](docs/decisions/adoption.md), [pendências](docs/decisions/open-questions.md) e [fronteiras de confiança](docs/security/trust-boundaries.md).
- [Cobertura normativa](docs/validation/normative-coverage.md), [fontes oficiais e lacunas](docs/validation/official-sources.md), [relatório de validação](docs/validation/report.md).
- [Proveniência com revisões](docs/structure/files.json); baseline recuperável em `docs/validation/adoption-baseline/`. Origens no manifesto são rótulos históricos da biblioteca, sem leitura externa no funcionamento normal.

## Consulta explícita

Peça ao agente: “Leia skills/plugin-protocol-engineering/SKILL.md para revisar a negociação de capacidades deste contrato”. Para SDD: “Leia sdd/project.md e sdd/workflow.md e retome a feature sdd/features/<nome>”. São instruções de conversa, não comandos de shell. Arquivos disponíveis não significam descoberta automática ou instalação no ambiente. Escolha uma primária por questão e auxiliares apenas para dúvidas distintas; não carregue a biblioteca inteira.

Condicionais: distributed-systems somente com garantias entre falhas independentes; engineering-productivity somente com avaliação de fluxo/ferramenta; prompt somente quando o artefato pedido é um prompt. gleam, kotlin e postgresql não estão no perfil.

## Verificação local

A partir desta raiz, Python 3.11+ e stdlib bastam. Não executar runners da biblioteca externa.

```bash
PYTHONDONTWRITEBYTECODE=1 python3 sdd/tools/validate.py --root .
PYTHONDONTWRITEBYTECODE=1 python3 sdd/tools/validate.py --root . --structure-only
PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/check-ox.py
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s src/tests -v
PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/run-checks.py
```

Prefira o último para coletar uma rodada completa: cada execução cria diretório novo em `docs/validation/runs/`, conserva saídas anteriores e registra ambiente, comandos, resultados e hashes dos inputs. Comandos individuais são somente leitura ou usam fixtures descartáveis em `docs/validation/scratch/`. Escolha apenas checks afetados ao retomar, sem repetir resultados verdes sem motivo.

O modo padrão valida estrutura e evidências disponíveis, inclusive critérios NÃO VERIFICADO. `--structure-only` serve às features em andamento. Não usar aprovação estrita global para estas features enquanto os cenários técnicos originais estiverem pendentes. `--require-fresh` exige schema 2; não prova que um oráculo é adequado ou que o produto funciona.

Testes locais cobrem rejeição de caminhos/links, identidade de pontes, critérios/JSON duplicados, aprovação sem evidência, invalidação seletiva e cópia independente com corrupção de recurso. Casos para avaliar agentes estão em `src/fixtures/evaluation-*.json`, com prompts sem gabarito em `agent-prompts-*.json`. Respostas observadas ficam em `docs/validation/agent-evals/`. Não executar agentes/serviços externos automaticamente.

## Componentes de preparação

`src/scripts/adopt-library.py`, `author-skills.py`, `configure-governance.py`, `prepare-evaluations.py` e `document-adoption.py` registram a materialização inicial. São scripts de autoria de uso único, não ferramentas de atualização ou validação recorrente. Não reexecutá-los sobre alterações do usuário. Comandos utilizados na raiz da biblioteca durante a preparação:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 ox/src/scripts/adopt-library.py
PYTHONDONTWRITEBYTECODE=1 python3 ox/src/scripts/author-skills.py
PYTHONDONTWRITEBYTECODE=1 python3 ox/src/scripts/configure-governance.py
PYTHONDONTWRITEBYTECODE=1 python3 ox/src/scripts/prepare-evaluations.py
PYTHONDONTWRITEBYTECODE=1 python3 ox/src/scripts/document-adoption.py
```

Adoção é a única ferramenta histórica que leu a origem externa; sua operação está encerrada e não é necessária depois de separar Ox. A baseline conserva os três originais e as cópias anteriores às adaptações; restaure em diretório vazio dentro de Ox e compare antes de aplicar, sem sobrescrever trabalho recente.

## Limites

Estrutura, revisão semântica, simulação controlada, resposta observada de agente e integração de produto são níveis diferentes. A aprovação de conteúdo de uma skill não aprova as funcionalidades que ela ensina. Versões do produto, plataformas, agentes iniciais, persistência, sandbox, distribuição e metas exigem decisões/evidências futuras.
