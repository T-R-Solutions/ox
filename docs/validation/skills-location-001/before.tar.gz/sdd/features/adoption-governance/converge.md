# Convergência — adoção da governança Ox

Data: 2026-10-26. Ambiente Linux, Python 3.13.16, sem Git. Trilha schema 2 em evidence.json contém método, resultado, artefato/hash e inputs de implementação/oráculo/configuração/contrato. Não se executou produto.

| AC | Vínculo | Alteração | Evidência / resultado | Estado |
|---|---|---|---|---|
| AC-01 | REQ-01 / D-01 / R-01 / T001,T005 | Baselines, manifesto e diff revisado | E-PRESERVE: 3117 arquivos externos e 3 originais preservados | APROVADO |
| AC-02 | REQ-02 / D-02 / R-02 / T002 | 29 skills e pontes com recursos | E-PROFILE: auditor local exit 0 | APROVADO |
| AC-03 | REQ-03 / D-03 / R-03 / T003,T005 | Constituição única, AGENTS, nove features de autoria e mapa normativo | E-NORM: 72 IDs revisados; GUI mantida futura | APROVADO documental |
| AC-04 | REQ-04 / D-04 / R-04 / T004 | Verificadores e casos permitidos | E-LOCAL: comandos passam; 8 testes; ensaios em registro separado | APROVADO no escopo local |

## Limites e retomada

Os 36 critérios AC-01..04 das nove features de skill permanecem NÃO VERIFICADO; esta adoção não os substitui nem aprova funcionalidades Ox. AC-05/06 de cada uma aprovam conteúdo e ensaios textuais delimitados. Pendências de plataforma, versões, agentes, armazenamento, sandbox, distribuição e desempenho estão em docs/decisions/open-questions.md.

Para manutenção local, ler spec/plan/tasks/converge e comparar os inputs atuais com evidence.json. Executar os comandos existentes em sdd/project.md apenas quando mudança/risco invalidar observações. Para integração futura retomar T004 de cada skill em consumidor autorizado, com o oráculo e cenário originais; registrar comandos reais quando implementação/ambiente existirem. Não solicitar aprovação estrita global enquanto critérios obrigatórios continuarem sem evidência.
