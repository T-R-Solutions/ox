from pathlib import Path
import json,re
root=Path(__file__).resolve().parents[2]
text=(root/'Ox_Regras_SDD_Skills_AGENTS_v1.0.md').read_text()
groups={
'INT':('docs/constitution.md','Papéis distintos e políticas fora das skills; pacote reutilizável e sem autorização implícita.'),
'AGT':('AGENTS.md','Entrada concisa com navegação, preservação, rotas, atualização de features e limites de autoridade; não é sandbox.'),
'SDD':('sdd/workflow.md','Fluxo copiado sem alteração; rota local e completa por risco, ampliação diante de incerteza e proibição de reduzir critérios.'),
'SPC':('sdd/features/skill-plugin-protocol-engineering/spec.md','Nove specs têm atores/precondições, REQ/AC em declarações próprias; critérios originais preservados; revisão sem aprovação de produto.'),
'PLN':('sdd/features/adoption-governance/plan.md','Decisões/riscos/alternativas e método realmente consultado; uma primária, auxiliares condicionais; ausência não simula uso.'),
'TSK':('sdd/features/skill-plugin-protocol-engineering/tasks.md','Tarefas com IDs, vínculos, arquivos e dependências; autoria e integração separadas; checkbox não aprova critérios.'),
'CHK':('sdd/templates/checklist.md','Template opcional preservado; não se criaram nove checklists redundantes; revisão documental distinta de teste.'),
'CNV':('sdd/evidence.md','Cinco estados e método/input/resultado/limites, retomada exata; convergências por critério sem aprovação por ausência de erro.'),
'CHN':('sdd/chain/README.md','29 pontes selecionáveis, paths reais e identidade confirmada pelo validador; nenhuma instalação ou cadeia automática.'),
'AUT':('docs/decisions/adoption.md','Conflitos por assunto/autoridade; unsafe próprio estrito explicitamente; recomendações restantes não promovidas; inputs afetados invalidam evidência.'),
'EVD':('sdd/evidence.md','Contrato original schema 2; observações com hashes reais e limitações; validação estrutural não demonstra eficácia ou integração.'),
'RET':('AGENTS.md','Retomar artefatos e bytes reais; comparar observações; não repetir checks verdes sem mudança; explicitar impedimento e próximo passo.'),
'GUI':('docs/architecture/context.md','Requisito de integração futura preservado: arquivos portáveis continuam autoridade; estados indicado/selecionado/consultado/usado e progresso/permissão distintos. GUI não implementada.')}
coverage={};rows=[]
for m in re.finditer(r'\*\*([A-Z]{3}-\d{3})\.\*\* (.*?)(?=\n\n|\Z)',text,re.S):
 id,rule=m.groups();authority,note=groups[id[:3]]
 coverage[id]={'authority':authority,'review':note,'state':'NÃO VERIFICADO' if id.startswith('GUI-') else 'APROVADO documental','rule':rule.replace('\n',' ')}
 rows.append(f"| {id} | {rule.replace(chr(10),' ').replace('|','/')} | `{authority}` | {'NÃO VERIFICADO (GUI futura)' if id.startswith('GUI-') else 'Revisão documental'} |")
(root/'src/fixtures/normative-coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
(root/'docs/validation/normative-coverage.md').write_text('''# Revisão normativa por ID

Método: comparação semântica pelo agente executor entre o documento de integração preservado, autoridades adotadas e features de autoria; complemento estrutural confere igualdade do conjunto de IDs. Data: 2026-10-26. Não é revisão humana independente nem execução do produto. Texto de cada regra abaixo mantém seu primeiro parágrafo; a regra completa e listas/tabelas continuam no documento original.

Os grupos INT/AGT/SDD/SPC/PLN/TSK/CHK/CNV/CHN/AUT/EVD/RET foram examinados como contratos de governança. A adequação operacional de runtime/UI permanece sem integração. Os seis GUI são preservados como requisitos futuros e não considerados implementados.

'''+ '\n\n'.join(f'**{g}**: {note}' for g,(_,note) in groups.items())+'\n\n| ID | Regra de referência | Implementação/autoridade | Evidência/limite |\n|---|---|---|---|\n'+'\n'.join(rows)+'\n')
(root/'docs/validation/official-sources.md').write_text('''# Fontes oficiais consultadas

Consulta web pelo agente executor em 2026-10-26. Não foram instaladas bibliotecas ou executados exemplos de produto. Conteúdo técnico das novas skills distingue fatos documentados e síntese de método; versões consultadas não são escolhas aprovadas para Ox. URLs externas são fontes de pesquisa, não dependências dos validadores locais.

| Competência | Fonte consultada | Observação aplicável e limite |
|---|---|---|
| Plugin protocol | [JSON-RPC 2.0](https://www.jsonrpc.org/specification) | Envelope e correlação; não define transporte, autorização ou isolamento |
| Agent runtime | [ACP initialization v1](https://agentclientprotocol.com/protocol/v1/initialization), [cancellation](https://agentclientprotocol.com/protocol/v1/cancellation) | Negociação/cancelamento; v2 draft separado; nenhum peer real testado |
| Agent runtime | [Rust Child](https://doc.rust-lang.org/std/process/struct.Child.html) | Drop não termina processo; não extrapolar para todo runtime |
| Autonomous verification | [SLSA provenance 1.2](https://slsa.dev/spec/v1.2/provenance) | Origem de artefatos não é aceitação funcional ou certificação SLSA |
| Workspace | [Git worktree](https://git-scm.com/docs/git-worktree), [Rust rename](https://doc.rust-lang.org/std/fs/fn.rename.html) | Estado compartilhado e semântica por plataforma; sem promessa de transação multiarquivo |
| Iced | [Guia 0.14.0](https://docs.rs/iced/0.14.0/iced/), [widget](https://docs.rs/iced/0.14.0/iced/widget/index.html), [advanced](https://docs.rs/iced/0.14.0/iced/advanced/index.html) | Message/update/view, Task/Subscription; confirmar API no consumidor |
| Context | [LSP 3.17](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/), [Tree-sitter incremental parsing](https://tree-sitter.github.io/tree-sitter/using-parsers/3-advanced-parsing.html) | Portal LSP acessível, extração detalhada do portal incompleta; ranges/capabilities exigem schema real; parsing não é resolução |
| Graph | [W3C PROV-DM](https://www.w3.org/TR/prov-dm/) | Vocabulário de proveniência; não requer RDF nem valida arestas inferidas |
| Output | [Cargo external tools](https://doc.rust-lang.org/cargo/reference/external-tools.html#json-messages) | JSON do build não cobre arbitrariamente subprocessos/testes |
| Usage | [OpenTelemetry GenAI attributes](https://opentelemetry.io/docs/specs/semconv/registry/attributes/gen-ai/), [repositório GenAI indicado pela fonte](https://github.com/open-telemetry/semantic-conventions-genai) | Página antiga sinaliza mudança/depreciação de localização; contrato de cada provedor ainda precisa ser observado; sem preços inventados |

## Lacunas e retomada

URLs diretas de pane_grid e advanced Widget para Iced 0.14.0 falharam nesta consulta. As páginas de módulos superiores responderam. A referência de layout não afirma assinaturas dessas APIs; confirmar documentação/source da versão escolhida antes de implementar widgets. O portal LSP retornou principalmente navegação; consultar schema da versão do servidor e testar Unicode antes de afirmar ranges corretos. OTel migrou as convenções GenAI para repositório próprio; fixar uma revisão ao implementar adaptadores. Nenhuma dessas lacunas impede os métodos reutilizáveis escritos, mas impede alegar compilação ou compatibilidade do consumidor.

Skill-creator foi lida integralmente no ambiente; cópia histórica em adoption-baseline. Seu quick_validate usa PyYAML, disponível aqui (6.0.3), mas o fluxo portátil obrigatório usa somente stdlib e o validador do SDD. Não há dependência operacional da skill-creator instalada fora deste projeto.
''')
(root/'README.md').write_text('''# Ox — governança e biblioteca

Preparação local concluída em artefatos; o aplicativo Ox não foi implementado. Preserve os três documentos originais na raiz. A [constituição](docs/constitution.md) é a única autoridade de políticas permanentes; [AGENTS.md](AGENTS.md) orienta agentes.

## Navegação

- [Contexto SDD e comandos](sdd/project.md), [workflow 1.3.0](sdd/workflow.md) e [evidências/schema 2](sdd/evidence.md).
- [Catálogo](skills/README.md): **29 skills** — 17 gerais copiadas, 3 condicionais copiadas, 5 novas P0 e 4 novas P1. As 20 existentes mantêm recursos e bytes de origem.
- [29 pontes](sdd/chain/README.md): 20 adaptadas e 9 novas, com paths relativos e identidade verificável.
- [Features](sdd/features/README.md): adoção de governança e nove SDDs `skill-*`, separados de futuras funcionalidades `product-*`.
- [Arquitetura e fases](docs/architecture/context.md), [decisões da adoção](docs/decisions/adoption.md), [pendências](docs/decisions/open-questions.md) e [fronteiras de confiança](docs/security/trust-boundaries.md).
- [Cobertura normativa](docs/validation/normative-coverage.md), [fontes oficiais e lacunas](docs/validation/official-sources.md), [relatório de validação](docs/validation/report.md).
- [Proveniência com revisões](docs/structure/files.json); baseline recuperável em `docs/validation/adoption-baseline/`. Origens no manifesto são rótulos históricos da biblioteca, sem leitura externa no funcionamento normal.

## Consulta explícita

Peça ao agente: “Leia skills/plugin-protocol-engineering/SKILL.md para revisar a negociação de capacidades deste contrato”. Para SDD: “Leia sdd/project.md e sdd/workflow.md e retome a feature sdd/features/<nome>”. São instruções de conversa, não comandos de shell. Arquivos disponíveis não significam descoberta automática ou instalação no ambiente. Escolha uma primária por questão e auxiliares apenas para dúvidas distintas; não carregue a biblioteca inteira.

Condicionais: distributed-systems somente com garantias entre falhas independentes; engineering-productivity somente com avaliação de fluxo/ferramenta; prompt somente quando o artefato pedido é um prompt. gleam, kotlin e postgresql não estão no perfil.

## Verificação local

A partir desta raiz, Python 3.11+ e stdlib bastam. Não executar runners da biblioteca externa.

```bash
PYTHONDONTWRITEBYTECODE=1 python3 sdd/tools/validate.py --root .
PYTHONDONTWRITEBYTECODE=1 python3 sdd/tools/validate.py --root . --structure-only
PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/check-ox.py
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s src/tests -v
PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/run-checks.py
```

Prefira o último para coletar uma rodada completa: cada execução cria diretório novo em `docs/validation/runs/`, conserva saídas anteriores e registra ambiente, comandos, resultados e hashes dos inputs. Comandos individuais são somente leitura ou usam fixtures descartáveis em `docs/validation/scratch/`. Escolha apenas checks afetados ao retomar, sem repetir resultados verdes sem motivo.

O modo padrão valida estrutura e evidências disponíveis, inclusive critérios NÃO VERIFICADO. `--structure-only` serve às features em andamento. Não usar aprovação estrita global para estas features enquanto os cenários técnicos originais estiverem pendentes. `--require-fresh` exige schema 2; não prova que um oráculo é adequado ou que o produto funciona.

Testes locais cobrem rejeição de caminhos/links, identidade de pontes, critérios/JSON duplicados, aprovação sem evidência, invalidação seletiva e cópia independente com corrupção de recurso. Casos para avaliar agentes estão em `src/fixtures/evaluation-*.json`, com prompts sem gabarito em `agent-prompts-*.json`. Respostas observadas ficam em `docs/validation/agent-evals/`. Não executar agentes/serviços externos automaticamente.

## Componentes de preparação

`src/scripts/adopt-library.py`, `author-skills.py`, `configure-governance.py`, `prepare-evaluations.py` e `document-adoption.py` registram a materialização inicial. São scripts de autoria de uso único, não ferramentas de atualização ou validação recorrente. Não reexecutá-los sobre alterações do usuário. Comandos utilizados na raiz da biblioteca durante a preparação:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 ox/src/scripts/adopt-library.py
PYTHONDONTWRITEBYTECODE=1 python3 ox/src/scripts/author-skills.py
PYTHONDONTWRITEBYTECODE=1 python3 ox/src/scripts/configure-governance.py
PYTHONDONTWRITEBYTECODE=1 python3 ox/src/scripts/prepare-evaluations.py
PYTHONDONTWRITEBYTECODE=1 python3 ox/src/scripts/document-adoption.py
```

Adoção é a única ferramenta histórica que leu a origem externa; sua operação está encerrada e não é necessária depois de separar Ox. A baseline conserva os três originais e as cópias anteriores às adaptações; restaure em diretório vazio dentro de Ox e compare antes de aplicar, sem sobrescrever trabalho recente.

## Limites

Estrutura, revisão semântica, simulação controlada, resposta observada de agente e integração de produto são níveis diferentes. A aprovação de conteúdo de uma skill não aprova as funcionalidades que ela ensina. Versões do produto, plataformas, agentes iniciais, persistência, sandbox, distribuição e metas exigem decisões/evidências futuras.
''')
# Initial adoption automation includes honest pending records.
f=root/'sdd/features/adoption-governance'
rows=[]
for i in range(1,5): rows.append({'acceptance':f'AC-{i:02d}','requirement':f'REQ-{i:02d}','decision':f'D-{i:02d}','risk':f'R-{i:02d}','tasks':[f'T00{i}'],'implementation':'AGENTS.md' if i==3 else 'skills/README.md' if i==2 else 'docs/structure/files.json' if i==1 else 'src/scripts/run-checks.py','oracle':'src/scripts/check-ox.py' if i!=3 else 'docs/validation/normative-coverage.md'})
(f/'traceability.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
(f/'evidence.json').write_text(json.dumps({'schema_version':2,'environment':'Adoção local, verificações em preparação.','requirements':[{'id':f'AC-{i:02d}','criterion':'Critério de adoção '+str(i),'status':'NÃO VERIFICADO','evidence_ids':[]} for i in range(1,5)],'evidence':[],'limitations':['Sem integração do produto.']},ensure_ascii=False,indent=2)+'\n')
print('Normative IDs:',len(coverage))
