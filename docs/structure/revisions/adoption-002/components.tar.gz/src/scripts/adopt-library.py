"""One-time adoption; refuse existing destinations. Run from Ox's parent only."""
from pathlib import Path
import hashlib, json, shutil, tarfile, re
root=Path.cwd(); ox=root/'ox'
assert (ox/'Ox_Comparativo_Skills_e_SDD_v1.0.md').is_file()
general='ai-engineering api-testing application-security database-engineering design-review design-system domain-modeling observability-and-diagnostics performance-engineering reliability-engineering rust software-architecture software-delivery software-design software-evolution software-testing technical-documentation'.split()
conditional={'distributed-systems':'Garantias entre processos com falhas independentes, ordenação, replay ou sincronização; IPC por si só não basta.', 'engineering-productivity':'Avaliação de fluxo humano ou ferramenta com baseline e resultado observável; não benchmark do binário.', 'prompt':'Pedido de criar ou revisar um prompt como artefato; não qualquer tarefa com IA.'}
new='plugin-protocol-engineering agent-runtime-engineering autonomous-verification-engineering workspace-integrity-engineering iced-engineering code-context-engineering code-knowledge-graph-engineering tool-output-engineering agent-usage-accounting'.split()
records=[]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(src,dst):
    assert not dst.exists(), dst
    dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
    records.append({'source':src.relative_to(root).as_posix(),'destination':dst.relative_to(ox).as_posix(),'source_sha256':sha(src),'copied_sha256':sha(dst)})
for name in general+list(conditional):
    for p in sorted((root/'skills'/name).rglob('*')):
        assert not p.is_symlink(), p
        if p.is_file(): copy(p,ox/p.relative_to(root))
for p in sorted((root/'sdd/model').rglob('*')):
    if p.is_file() and '__pycache__' not in p.parts: copy(p,ox/'sdd'/p.relative_to(root/'sdd/model'))
for name in general+list(conditional): copy(root/'sdd/chain'/f'{name}.md',ox/'sdd/chain'/f'{name}.md')
base=ox/'docs/validation/adoption-baseline'
with tarfile.open(base/'copied-before-adaptation.tar.gz','w:gz') as archive:
    for row in records: archive.add(ox/row['destination'],arcname=row['destination'])
(ox/'docs/structure').mkdir(parents=True)
(ox/'docs/structure/files.json').write_text(json.dumps({'schema_version':1,'source_namespace':'library-relative historical provenance; not a runtime dependency','revisions':[{'id':'copy-001','records':records}]},ensure_ascii=False,indent=2)+'\n')
(ox/'src/fixtures').mkdir(parents=True)
(ox/'src/fixtures/profile.json').write_text(json.dumps({'general':general,'conditional':conditional,'new':new,'excluded':['gleam','kotlin','postgresql']},ensure_ascii=False,indent=2)+'\n')
for name in general+list(conditional):
    p=ox/'sdd/chain'/f'{name}.md'
    text=p.read_text().replace('skill_path: UNCONFIGURED',f'skill_path: skills/{name}/SKILL.md')
    if name in conditional: text+='\n## Perfil condicional do projeto\n\n'+conditional[name]+' Disponibilidade não significa seleção, consulta ou uso.\n'
    p.write_text(text)
f=ox/'sdd/features/adoption-governance'; f.mkdir(parents=True)
(f/'spec.md').write_text('''# Adoção da governança e biblioteca Ox

Ator: mantenedor e agentes autorizados. Precondição: três propostas fornecidas e biblioteca local disponível. Escopo: somente governança, skills, evidências e verificadores locais dentro desta raiz. Aplicação, crates, plugins e serviços excluídos.

- REQ-01: Preservar fontes e alterações externas; copiar recursos completos com proveniência recuperável.
- REQ-02: Instalar 17 gerais, 3 condicionais e autorar 9 especializações com pontes portáveis.
- REQ-03: Adotar contratos SDD 1.3.0, autoridade única e critérios honestos separados do produto.
- REQ-04: Verificar estrutura, regressões dos verificadores e casos de seleção/comportamento permitidos.
- AC-01 → REQ-01: Hashes iniciais e finais confirmam três originais intactos e árvore externa sem alterações.
- AC-02 → REQ-02: Inventário exato, recursos íntegros e 29 pontes com identidade e caminho válidos passam no auditor local.
- AC-03 → REQ-03: Revisão por ID cobre todas as regras normativas e preserva decisões abertas, cinco estados e nove features de autoria.
- AC-04 → REQ-04: Validador copiado e testes locais passam; relatório separa estrutura, revisão, simulação, agente e integração.

Rejeitar aprovação de funcionalidades do produto por êxito da documentação. Plataformas, versões e sandbox permanecem pendências, sem impedir autoria independente.
''')
(f/'plan.md').write_text('''# Plano de adoção — rota completa

Registro anterior à cópia/adaptação de conteúdo autoral. Rota completa por contratos, governança, consumidores independentes e integridade. Baseline inicial já capturada; nenhuma alteração preexistente será sobrescrita.

| ID | Requisitos | Decisão / risco | Alternativa e custo | Reavaliar |
|---|---|---|---|---|
| D-01 | REQ-01 | Cópias completas e snapshots locais com SHA-256 | Referências à biblioteca externa quebrariam portabilidade | Atualização upstream |
| D-02 | REQ-02 | 20 existentes e 9 novas; autoria começa PLUG, AGENT, VERIFY | Duplicar competências absorvidas aumenta ambiguidade | Avaliação real de seleção |
| D-03 | REQ-03 | Constituição única em docs; sdd/constitution.md aponta autoridade | Duas políticas concorrentes causariam deriva | Mudança autorizada de política |
| D-04 | REQ-04 | Checks stdlib e casos controlados; integração futura separada | Implementar o produto excederia o pedido | Disponibilidade do produto |
| R-01 | REQ-01 | Escrita fora da raiz ou perda de origem | Comparar baseline externa e originais | Qualquer divergência |
| R-02 | REQ-02 | Novas skills vagas ou sobrepostas | Referências concretas e prompts positivos/negativos | Falha observada |
| R-03 | REQ-03 | Proposta promovida a decisão; aprovação falsa | Mapa normativo e convergência por AC | Mudança de contrato |
| R-04 | REQ-04 | Oráculo só testa palavras ou confunde simulação e produto | Testes de mutação do validador e avaliação delimitada | Evidência insuficiente |

Competência primária consultada: skill-creator do ambiente, versão não declarada. Conteúdo de origem preservado em docs/validation/adoption-baseline/skill-creator.md; sem ponte no Ox, sem instalação. Pergunta: como autorar competências reutilizáveis com seleção precisa e referências progressivas? Entrega: nove entradas, referências e casos. Inspeção das entradas da biblioteca serve à comparação, não declara uso de todas elas. Novas skills não foram consultadas durante sua própria autoria. Auxiliares não selecionadas automaticamente.

Ordem: baseline e contratos; PLUG → AGENT → VERIFY; workspace e Iced; contexto → grafo; output e contabilidade sobre contratos de eventos. Essa dependência orienta autoria, sem impor bibliotecas em runtime.
''')
(f/'tasks.md').write_text('''# Tarefas da adoção

- [ ] T001 [REQ-01, AC-01, D-01, R-01]: capturar baseline, inventário e cópias com hashes; arquivos docs/structure e docs/validation; sem dependências.
- [ ] T002 [REQ-02, AC-02, D-02, R-02]: autorar nove skills, recursos e 29 pontes; depende T001; concluir após revisão de fronteiras e auditoria.
- [ ] T003 [REQ-03, AC-03, D-03, R-03]: registrar constituição, AGENTS, projeto, nove features e cobertura normativa; depende T001.
- [ ] T004 [REQ-04, AC-04, D-04, R-04]: executar validação copiada, testes locais e avaliações autorizadas; depende T002/T003; preservar cada rodada.
- [ ] T005 [REQ-01, REQ-03, AC-01, AC-03, D-01, R-01]: inspecionar diff, append de revisões, hashes e convergência final; depende T004.
''')
(f/'converge.md').write_text('# Convergência em andamento\n\nAC-01 a AC-04: NÃO VERIFICADO. Retomar após T004 e inspeção final.\n')
print(f'Copied {len(records)} files; preserved before adaptation.')
