"""Historical adoption boundary audit; explicitly read source root, never write it."""
from pathlib import Path
import argparse,hashlib,json,os,sys
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[2]
def snapshot(root):
 entries={}
 for base,dirs,files in os.walk(root,followlinks=False):
  p=Path(base)
  if p==root:dirs[:]=[d for d in dirs if d!='ox']
  for n in files+[d for d in dirs if (p/d).is_symlink()]:
   f=p/n;rel=f.relative_to(root).as_posix()
   if f.is_symlink():entries[rel]={'symlink':os.readlink(f)}
   elif f.is_file():
    h=hashlib.sha256()
    with f.open('rb') as stream:
     for b in iter(lambda:stream.read(1024*1024),b''):h.update(b)
    entries[rel]={'sha256':h.hexdigest(),'size':f.stat().st_size}
 return entries
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--source-root',type=Path,required=True);args=parser.parse_args();source=args.source_root.resolve()
 if source/'ox'!=ROOT:parser.error('This historical audit requires the original parent/Ox layout.')
 before=json.loads((ROOT/'docs/validation/adoption-baseline/outside-tree.json').read_text());after=snapshot(source)
 changes=[p for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)]
 originals=json.loads((ROOT/'docs/validation/adoption-baseline/originals.json').read_text())
 original_changes=[p for p,h in originals.items() if hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=h]
 result={'outside_files_before':len(before),'outside_files_after':len(after),'outside_changed':changes,'original_changed':original_changes,'method':'SHA-256 of all regular files outside ox; symlink targets compared without following; no Git repository','limitation':'Does not claim unchanged access timestamps or detect transient changes reverted before comparison.'}
 dest=ROOT/'docs/validation'/('boundary-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')+'.json');dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(result,ensure_ascii=False));print('Evidence:',dest.relative_to(ROOT));sys.exit(bool(changes or original_changes))
