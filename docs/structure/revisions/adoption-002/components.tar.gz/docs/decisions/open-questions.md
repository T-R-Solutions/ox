# Decisões abertas

Nenhuma destas decisões é indispensável à autoria local desta biblioteca. Antes de implementar o consumidor, registrar uma ADR por decisão material com alternativas, autoridade e critérios.

| ID | Estado | Decisão / impacto | Retomada |
|---|---|---|---|
| OPEN-01 | PENDENTE | Plataformas iniciais e matriz de SO/FS/GPU | Mantenedor define targets; testar isolamento, recuperação e Iced em cada um |
| OPEN-02 | PENDENTE | Rust MSRV/edition/toolchain, Iced/features e runtime | Criar contrato de versões e lockfile somente na implementação autorizada; Tokio é candidata |
| OPEN-03 | PROPOSTA | Processo externo/IPC versionado, JSON-RPC, ACP | Escolher protocolo/transportes e agentes após verificar versões/capabilities reais; sem ABI ou sandbox presumidos |
| OPEN-04 | PENDENTE | Primeiros agentes, rede, segredos e graus de autonomia | Definir adaptadores e grants; distinguir mediação do host de ferramentas diretas |
| OPEN-05 | PROPOSTA | SQLite, FTS5, formato de grafo, backup e retenção | Comparar alternativas com workload, recuperação e política de dados |
| OPEN-06 | PENDENTE | Sandbox por plataforma e plugins confiáveis | Modelo de ameaças e testes de efeitos negados em SO alvo |
| OPEN-07 | PENDENTE | Distribuição, licença, assinatura, atualização e SDK público | Decisão comercial/técnica antes de publicar; software-delivery cobre o método |
| OPEN-08 | PENDENTE | Metas de CPU/RAM/latência, corpus e acessibilidade | Spike/benchmark autorizado com hardware fixado; nenhum número adotado agora |
| OPEN-09 | PENDENTE | Parsers, linguagens prioritárias, C/FFI transitivo | Auditar dependências; first-party Rust é definido, ausência absoluta de C não foi imposta |
| OPEN-10 | HIPÓTESE | Embeddings, nuvem opt-in, marketplace e economia de tokens | Avaliação comparativa futura; fora do MVP e desta preparação |
| OPEN-11 | PENDENTE | UX de aprovação, idiomas, multijanela, layout final | Validar com usuários/targets e manter arquivos SDD como autoridade |

Propostas não autorizam instalar dependências, executar agentes externos, transmitir código, gastar, publicar ou implementar o aplicativo nesta tarefa.
