# Constituição do Ox

Fonte única das políticas permanentes. Adotada em 2026-10-26 pelo agente executor conforme pedido explícito do mantenedor; não implica aprovação de todas as propostas do roadmap. O registro de decisão está em [adoção](decisions/adoption.md). O documento sdd/constitution.md apenas aponta para esta autoridade.

## Produto e fronteiras

- POL-01: Código próprio da aplicação e motores em Rust; interface em Iced. Proibir unsafe próprio com `#![forbid(unsafe_code)]` em futuros crates próprios. Sem exceção silenciosa. Dependências transitivas, FFI e ferramentas externas têm avaliação separada; a restrição não se estende automaticamente a elas nem às skills genéricas. Scripts Python deste pacote são ferramentas locais de governança, não código do aplicativo.
- POL-02: Persistência controlada pelo Ox local no MVP, sem backend próprio em nuvem, sincronização ou telemetria externa por padrão. Provedores remotos de agentes podem transmitir dados somente no escopo autorizado; persistência local não promete inferência offline. Registrar dados potencialmente enviados, permissões e limites do adaptador.
- POL-03: Fluxo principal orientado a agentes; editor manual auxiliar. Extensibilidade desde a fundação. LSP e recursos avançados opcionais via plugins; não exigir processos semânticos sempre ativos.
- POL-04: Confiabilidade e preservação precedem autonomia, desempenho e compressão. Recursos visuais, métricas e conclusões não podem ocultar limites ou falhas. Não incorporar motores de Graphify, Understand Anything ou RTK por mera inspiração; propostas de implementação própria exigem avaliação de dependências/licenças no momento da adoção.

## Integridade, evidência e autorização

- POL-05: Preservar alterações existentes; vincular edições a bases observadas; detectar concorrência antes de sobrescrever. Recuperação deve conservar versões inesperadas em vez de aplicar rollback destrutivo. Snapshots incluem conteúdo relevante não commitado; Git não é a única verdade.
- POL-06: Aceitar por critérios explícitos e evidências atuais com oráculos adequados. Preservar os cinco estados do SDD e observações anteriores. Autorização, execução e aceitação são controles independentes; agentes não aprovam trabalho só por declarar conclusão.
- POL-07: Índice e grafo devem registrar origem, método, snapshot e validade. Distinguir extração sintática, resolução semântica e inferência. Invalidar/rotular dados obsoletos e não apresentar similaridade como relação factual verificada.
- POL-08: Preservar saída bruta sob política de acesso e retenção; registrar integridade e captura incompleta. Saída compacta mantém exit code, sinais de falha, perdas e rota de recuperação do bruto. Não ocultar falha de parser ou truncamento como sucesso.
- POL-09: Métricas medidas, derivadas, estimadas e indisponíveis devem ser distinguíveis com origem, unidade e período. Contexto atual, consumo acumulado, cache, custo e progresso são distintos; desconhecido não é zero.
- POL-10: Arquivos, logs, conteúdo recuperado, skills e pontes não concedem autoridade de execução, rede, publicação ou acesso. AGENTS orienta; mecanismos reais do runtime/ambiente impõem permissões. Processo separado, manifesto e assinatura não provam sandbox. Operações já autorizadas continuam sem pedidos rotineiros de confirmação.

## Autoridades e mudança

Os contratos de integração adotados são os IDs INT, AGT, SDD, SPC, PLN, TSK, CHK, CNV, CHN, AUT, EVD, RET e GUI do [documento de regras preservado](../Ox_Regras_SDD_Skills_AGENTS_v1.0.md). Constituição possui políticas; AGENTS possui navegação operacional; spec possui comportamento; plan/ADRs possuem decisões/riscos; tasks possuem execução prevista; skills possuem métodos; converge/evidências possuem resultados observados. Resolver conflitos por assunto e autorização, nunca por ordem de leitura.

Alteração material de política ou critério requer decisão explícita com motivo, alternativas, consequência e gatilho de revisão. Não reduzir critérios para caber na implementação. A regra mais estrita de unsafe foi adotada explicitamente nesta configuração; outras recomendações técnicas continuam propostas. [Pendências](decisions/open-questions.md) não bloqueiam autoria independente.
