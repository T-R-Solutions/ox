# Adoção da governança e biblioteca Ox

Ator: mantenedor e agentes autorizados. Precondição: três propostas fornecidas e biblioteca local disponível. Escopo: somente governança, skills, evidências e verificadores locais dentro desta raiz. Aplicação, crates, plugins e serviços excluídos.

- REQ-01: Preservar fontes e alterações externas; copiar recursos completos com proveniência recuperável.
- REQ-02: Instalar 17 gerais, 3 condicionais e autorar 9 especializações com pontes portáveis.
- REQ-03: Adotar contratos SDD 1.3.0, autoridade única e critérios honestos separados do produto.
- REQ-04: Verificar estrutura, regressões dos verificadores e casos de seleção/comportamento permitidos.
- AC-01 → REQ-01: Hashes iniciais e finais confirmam três originais intactos e árvore externa sem alterações.
- AC-02 → REQ-02: Inventário exato, recursos íntegros e 29 pontes com identidade e caminho válidos passam no auditor local.
- AC-03 → REQ-03: Revisão por ID cobre todas as regras normativas e preserva decisões abertas, cinco estados e nove features de autoria.
- AC-04 → REQ-04: Validador copiado e testes locais passam; relatório separa estrutura, revisão, simulação, agente e integração.

Rejeitar aprovação de funcionalidades do produto por êxito da documentação. Plataformas, versões e sandbox permanecem pendências, sem impedir autoria independente.
