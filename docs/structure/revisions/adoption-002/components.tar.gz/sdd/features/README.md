# Features de governança e autoria

`adoption-governance` registra esta adoção. Nove diretórios `skill-*` registram autoria/avaliação, não funcionalidades do produto. Futuras features `product-*` precisam de critérios e evidências independentes. Não mover features para escapar de gates; o validador percorre os diretórios diretos desta pasta.
