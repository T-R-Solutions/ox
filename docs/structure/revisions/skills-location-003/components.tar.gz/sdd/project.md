# Contexto do projeto Ox

## Objetivo e escopo atual

Preparar uma biblioteca e governança portáveis para aplicação desktop agent-first. Esta adoção não implementa aplicação, crates, UI, serviços ou plugins. Todos os arquivos operacionais resolvem dentro desta raiz; origens históricas são proveniência, nunca dependência de execução.

## Autoridades

- `AGENTS.md`: entrada operacional; `docs/constitution.md`: única política permanente; `sdd/constitution.md`: apontador.
- `Ox_Regras_SDD_Skills_AGENTS_v1.0.md`: contratos de integração adotados; cobertura em `docs/validation/normative-coverage.md`.
- `Ox_Comparativo_Skills_e_SDD_v1.0.md`: perfil, fronteiras, nove contratos de autoria; `Ox_Roadmap_Arquitetura_v0.2.md`: contexto e fases, mantendo recomendações como propostas.
- `docs/decisions/adoption.md` e `docs/decisions/open-questions.md`: conflitos e decisões abertas; `docs/architecture/context.md`: fronteiras e fases.

## Features e métodos

Features diretas em `sdd/features/`: `adoption-governance` e nove `skill-<nome>`. O prefixo skill identifica autoria da biblioteca. Nenhuma feature de produto foi criada; futuras features de produto devem usar prefixo `product-` e evidências próprias. O validador verifica diretórios diretos, não depender de recursão implícita.

Uma primária quando pertinente, auxiliares para perguntas distintas; paths e bridge_version pertencem às pontes. A disponibilidade de 29 entradas não ativa nenhuma delas automaticamente. Critérios técnicos originais AC-01..04 das nove skills permanecem separados de AC-05/06 de conteúdo/avaliação.

## Stack e versões observadas

Rust e Iced definidos para o aplicativo; não há Cargo.toml, lockfile, compilação, MSRV ou versões adotadas. Ferramentas desta preparação usam somente Python 3.11+ e stdlib; Python observado 3.13.16 em Linux, detalhes em `docs/validation/adoption-baseline/environment.json`. Não há repositório Git. SDD copiado: 1.3.0, validador preservado byte a byte. Documentação consultada: Iced 0.14.0, ACP v1 (v2 draft separado), LSP 3.17, JSON-RPC 2.0, SLSA 1.2; são referências, não dependências instaladas. Fontes e lacunas em `docs/validation/official-sources.md`.

## Comandos existentes (cwd: raiz Ox)

```bash
PYTHONDONTWRITEBYTECODE=1 python3 sdd/tools/validate.py --root .
PYTHONDONTWRITEBYTECODE=1 python3 sdd/tools/validate.py --root . --structure-only
PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/check-ox.py
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s src/tests -v
PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/run-checks.py
```

O runner preserva cada rodada em diretório novo e mantém seus logs e hashes. O validador é somente leitura. Não solicitar aprovação estrita global enquanto existirem critérios sem evidência. Schema 2 vincula observações decididas aos inputs reais; hashes não atestam adequação do oráculo.

## Adaptações e pendências

Adaptações restritas a projeto, apontador constitucional, catálogo e skill_path das pontes. Templates, workflow, evidence e ferramenta mantidos. Cache Python da origem não é recurso portátil e foi excluído da cópia do modelo. Skills existentes copiadas integralmente sem reescrita. Nenhum runner externo é usado. Plataformas, sandbox, distribuição, agentes, persistência, runtime e metas continuam pendentes no registro de decisões.

## Correção da localização das skills

Por solicitação do mantenedor, o catálogo ativo está em `.codex/skills/`; todas as 29 pontes e referências operacionais usam essa localização. `skills/` nos documentos originais, snapshots e observações anteriores permanece referência histórica. Registro: `docs/validation/skills-location-001/report.md`. Não há cópia ativa em `skills/`.
