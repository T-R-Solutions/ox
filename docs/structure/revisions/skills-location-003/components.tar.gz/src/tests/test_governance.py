"""Adversarial tests for adopted validator and Ox-specific preservation checks."""
from pathlib import Path
import importlib.util,json,shutil,tempfile,unittest
ROOT=Path(__file__).resolve().parents[2]
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path); module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
V=load('sdd_validator',ROOT/'sdd/tools/validate.py')
C=load('ox_checker',ROOT/'src/scripts/check-ox.py')
class GovernanceTests(unittest.TestCase):
 def setUp(self):
  scratch=ROOT/'docs/validation/scratch';scratch.mkdir(parents=True,exist_ok=True)
  self.temp=tempfile.TemporaryDirectory(dir=scratch);self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
 def test_declared_criteria_ignore_examples(self):
  self.assertEqual(V.acceptance_ids('- AC-01 → REQ-01: required\n```md\n- AC-02: example\n```\n> AC-03: quote\n'),{'AC-01'})
 def test_duplicate_criterion_rejected(self):
  with self.assertRaises(ValueError): V.acceptance_ids('- AC-01: one\n- AC-01: two\n')
 def test_duplicate_json_rejected(self):
  p=self.root/'dup.json';p.write_text('{"status":"APROVADO","status":"NÃO VERIFICADO"}')
  with self.assertRaises(ValueError): V.strict_json(p)
 def test_path_escape_and_symlink(self):
  (self.root/'ok').write_text('ok');self.assertTrue(V.local_file(self.root,'ok').is_file())
  with self.assertRaises(ValueError): V.local_file(self.root,'../missing')
  outside=self.root/'other';outside.mkdir();(outside/'file').write_text('x')
  inside=self.root/'inside';inside.mkdir();(inside/'link').symlink_to(outside/'file')
  with self.assertRaises(ValueError): V.local_file(inside,'link')
 def test_bridge_identity_and_unconfigured(self):
  folder=self.root/'sdd/chain';folder.mkdir(parents=True)
  p=folder/'rust.md';p.write_text('---\nskill: rust\nskill_path: UNCONFIGURED\nbridge_version: 1\n---\n')
  self.assertTrue(any('Unconfigured' in e for e in V.bridge_errors(self.root,folder)))
  skill=self.root/'.codex/skills/rust';skill.mkdir(parents=True);(skill/'SKILL.md').write_text('---\nname: wrong\ndescription: test\n---\n')
  p.write_text(p.read_text().replace('UNCONFIGURED','.codex/skills/rust/SKILL.md'))
  self.assertTrue(any('mismatch' in e for e in V.bridge_errors(self.root,folder)))
 def test_missing_artifact_not_approved(self):
  doc={'schema_version':2,'environment':'fixture','limitations':[],'evidence':[],'requirements':[{'id':'AC-01','criterion':'tested','status':'APROVADO','evidence_ids':[]}]}
  self.assertTrue(any('without evidence' in e for e in V.evidence_errors(doc,self.root)))
  doc['requirements'][0]['status']='NÃO VERIFICADO';self.assertEqual(V.evidence_errors(doc,self.root),[])
 def test_freshness_selective_invalidation(self):
  a=self.root/'a';b=self.root/'b';a.write_text('A0');b.write_text('B0')
  doc={'schema_version':2,'requirements':[],'evidence':[{'id':'E-A','inputs':[{'path':'a','sha256':V.digest(a),'role':'implementation'}]},{'id':'E-B','inputs':[{'path':'b','sha256':V.digest(b),'role':'implementation'}]}]}
  self.assertEqual(V.input_errors(doc,self.root,[],self.root,True),[])
  a.write_text('A1');errors=V.input_errors(doc,self.root,[],self.root,True)
  self.assertEqual(len(errors),1);self.assertIn('E-A',errors[0]);self.assertNotIn('E-B',errors[0])
 def test_independent_copy_and_corrupt_resource(self):
  dest=self.root/'detached';dest.mkdir()
  # Copy only operative tree and preservation dependencies, never parent/library.
  for name in ['.codex/skills','sdd','src']:
   shutil.copytree(ROOT/name,dest/name,ignore=shutil.ignore_patterns('__pycache__'))
  shutil.copytree(ROOT/'docs/structure',dest/'docs/structure')
  shutil.copytree(ROOT/'docs/validation/adoption-baseline',dest/'docs/validation/adoption-baseline')
  for p in ROOT.glob('*.md'): shutil.copy2(p,dest/p.name)
  for directory in ['decisions','architecture','security']:
   shutil.copytree(ROOT/'docs'/directory,dest/'docs'/directory)
  shutil.copy2(ROOT/'docs/constitution.md',dest/'docs/constitution.md')
  # Copy reports needed by links/evidence, excluding recursive scratch and runs only when absent.
  for p in (ROOT/'docs/validation').iterdir():
   if p.name in {'scratch','adoption-baseline'}:continue
   if p.is_file(): shutil.copy2(p,dest/'docs/validation'/p.name)
   elif p.is_dir(): shutil.copytree(p,dest/'docs/validation'/p.name)
  self.assertEqual(C.check(dest),[])
  self.assertEqual(V.audit(dest),[])
  target=dest/'.codex/skills/rust/references/design.md';target.write_text(target.read_text()+'\ncorruption\n')
  self.assertTrue(any('Copied resource changed' in e for e in C.check(dest)))
if __name__=='__main__':unittest.main()
