"""One-time authorship materialization from preserved contracts plus reviewed methods."""
from pathlib import Path
import re,json
root=Path(__file__).resolve().parents[2]
source=(root/'Ox_Comparativo_Skills_e_SDD_v1.0.md').read_text()
DATA={
'plugin-protocol-engineering':{
'description':'Design and verify versioned host-plugin protocols, capability negotiation and lifecycle failure boundaries. Use for plugin hosts or compatibility changes; skip clients of an unchanged SDK.',
'steps':[
'Inventory each operation as a tuple: caller identity, requested capability, granted scope, input limit, effect, idempotency rule and revocation point. Separate host-mediated effects from direct process access; an allowlist in a manifest cannot constrain the latter.',
'Write a negotiation transcript before implementation. Define transport framing, maximum frame size, protocol version ranges, unknown fields, request correlation and error ownership. Compute effective capabilities as the supported/requested/granted intersection; never grant a capability merely because both binaries implement it.',
'Compare out-of-process RPC, in-process ABI and a restricted runtime against the actual trust model. Record which failure each option contains, platform mechanisms required and what remains trusted. Do not default to Wasm, gRPC or dynamic libraries.',
'Define lifecycle transitions from discovery through negotiation, ready, draining and stopped/failed. Admission closes before shutdown; in-flight requests either finish or expire under a documented policy. Reconnect creates a new instance generation, so old replies cannot satisfy new requests.',
'Build a compatibility matrix by host version, plugin version and capability subset. Exercise successful negotiation, denied capability, malformed frame, oversized payload, crash mid-effect and timeout. Inspect persistent state and protected-file effects, not just the error response.',
'Deliver a protocol contract, denied-effect matrix, lifecycle transcript and platform-specific residual risks. Treat a successful mock as protocol evidence only; isolate and test a real untrusted plugin before claiming sandbox enforcement.'
],
'refs':{
'protocol-negotiation':'''# Negotiation and message identity

Choose framing independently from message semantics: JSON-RPC does not select a transport. Requests carry IDs; notifications do not receive responses. Version the host protocol independently from plugin package versions. [JSON-RPC 2.0](https://www.jsonrpc.org/specification) defines this envelope, not permissions or a plugin ABI.

Design record (not a wire standard): instance_generation, request_id, protocol_version, requested_capabilities, granted_capabilities, deadline. Require a complete negotiation before admitting effects. If the peer claims unsupported optional features, disable them explicitly; if a mandatory feature is absent, reject startup without partial activation.

Example oracle: host supports read/search, plugin asks read/write, grant is read on root A. The only effective grant is read on A. A later write request is denied even if its JSON is valid. An old-generation reply after restart must be recorded as stale, not applied to a reused request ID. Specify duplicate-ID handling and size limits before choosing serialization libraries.
''',
'permissions-and-isolation':'''# Mediated permissions and containment

For each effect, list whether it passes through the host or is available directly to the plugin process. Test both paths. Capability checks protect the first; OS/container/runtime controls are needed for the second. A process boundary contains some crashes but does not revoke the user's filesystem or network permissions.

Bind grants to identity, instance, resource scope, operation and lifetime. Recheck revocation at the effect boundary, not only at handshake. Normalize and constrain file handles using mechanisms supported by the target platform; a string prefix comparison is insufficient for paths.

Use an isolated disposable directory with an allowed file and a denied sentinel. Observe sentinel content and access outcome after the denied operation. A mock returning permission_denied cannot establish that a native process could not bypass IPC. If the OS mechanism is undecided, deliver a threat/control matrix with that cell unverified. Authentication, signatures and containment answer different questions.
''',
'versioning-and-faults':'''# Compatibility and failure windows

Test host N/plugin N, host N/plugin N+1 and host N+1/plugin N only when the declared compatibility range promises them. Include unknown optional fields and missing required fields. Reject incompatible semantics rather than parsing a new value into an old default.

Track request admission, effect start, durable effect, reply delivery and resource release. A crash after the effect but before the reply creates an uncertain outcome: replaying a non-idempotent request may duplicate it. Use an operation key with a documented reconciliation lookup, or return uncertain and require inspection. Do not promise exactly-once from message IDs alone.

Recovery tests need a deadline, captured exit reason, remaining handles and persistent before/after state. Terminate a test peer at each window, then verify that admission closes, requests resolve or expire and restart does not inherit old grants. Upgrades need rollback behavior for both protocol and plugin-owned state.
'''}},
'agent-runtime-engineering':{
'description':'Engineer CLI agent supervision, session state, event ordering, cancellation and recovery. Use for process adapters and execution lifecycles; skip prompt writing and model-quality evaluation without process effects.',
'steps':[
'Inspect the actual executable, version, launch contract, transport and supported operations. Build an adapter capability table for cancel, resume, permission requests and usage reporting. Missing capabilities remain unavailable; do not emulate pause or resume by inventing protocol messages.',
'Separate session ID, task ID, execution attempt, process identity and event sequence. Define allowed transitions and guards. An adapter statement such as done is a reported event; process exit, file changes and acceptance evidence are distinct observations.',
'Supervise stdin/stdout/stderr concurrently with bounded queues and an overflow policy that preserves critical events. Decide where backpressure blocks, where raw bytes spill to disk, and how failure to persist them surfaces. Never parse human stderr as authoritative permissions.',
'Design cancellation as a request followed by an observed terminal outcome. Stop new work, cancel supported protocol operations, drain outputs, enforce a deadline, terminate the owned process tree through supported platform mechanisms, and reap processes. Record partial effects before permitting retries.',
'On reconnection, compare generation and last acknowledged event. Deduplicate recorded events, expose sequence gaps and reconcile artifacts before replaying side effects. A new process does not inherit old grants implicitly.',
'Exercise out-of-order events, death with unread streams, cancellation under sustained output and done without evidence. Deliver a transition table, adapter contract and execution trace with remaining cleanup/permission limitations.'
],
'refs':{
'session-state-machine':'''# Session and execution state

Use separate state machines for a conversational session and a concrete execution attempt. A session may survive several failed attempts; a completed process does not imply an accepted task. A useful attempt model is starting → running → cancelling → exited/failed, with an independent evidence verdict.

Each event needs session, attempt/generation, source, sequence or observation time, payload schema and raw locator. Reject a running event from an older generation after restart. Preserve an unexpected event for diagnosis while preventing it from reversing a terminal state. Define which events can legitimately arrive late and where gaps force reconciliation.

Counterexample: attempt A emits done, dies, then a delayed output arrives after attempt B starts. Applying it to B corrupts provenance. Route it to A, retain it, and leave task acceptance unchanged until its criterion-specific oracle runs. Runtime state should not be reconstructed from rendered chat text.
''',
'process-supervision':'''# Supervision and resource ownership

Assign an owner to process handles, output drainers, temporary files and permissions. Maintain a cleanup ledger so a failure can identify resources still owned. [Rust Child documentation](https://doc.rust-lang.org/std/process/struct.Child.html) states that dropping a Child does not stop it; waiting is also relevant to resource reclamation. Verify corresponding semantics for the selected async runtime instead of assuming equivalence.

Prevent pipe deadlocks by consuming both streams while the child runs. Bound memory without silently discarding evidence: spill raw output under a retention policy or fail visibly when storage is exhausted. Cancellation must remain deliverable while output queues are full.

Test with a controlled emitter that writes both streams, then ignores cooperative cancellation. Record deadlines, escalation, exit, drainer completion and descendants still alive. Killing the parent alone is not a portable guarantee about descendants. Termination strategy requires OS-specific validation; do not claim it from a pure state-machine test.
''',
'acp-and-cli-adapters':'''# ACP and CLI adapters

The consulted [ACP initialization v1](https://agentclientprotocol.com/protocol/v1/initialization) negotiates version and capabilities; use the schema matching the observed peer. The documentation also exposes a v2 draft: do not mix its messages with a v1 adapter. No agent executable/version is selected by this skill.

For [ACP cancellation](https://agentclientprotocol.com/protocol/v1/cancellation), distinguish sending a cancellation notification from observing the turn stop. Preserve events already in flight. Cancellation is not a rollback of filesystem effects.

For a plain CLI, prefer documented machine output. If only terminal text exists, expose a narrower adapter with explicit uncertainty: process started/exited can be observed, semantic completion may not be. Persist raw streams and invocation configuration without secrets. Compare declared support, negotiated support and tested support in separate columns. A CLI able to run tools directly may bypass host mediation; document that boundary before enabling execution.
'''}},
'autonomous-verification-engineering':{
'description':'Design criterion-based acceptance gates for autonomous work, binding verdicts to observed inputs and independent oracles. Use for evidence and approval engines; skip ordinary unit-test authoring without acceptance orchestration.',
'steps':[
'Enumerate normative acceptance criteria and identify their authority. For each, name the implementation surface, oracle, execution permission and expected failure. Do not derive expected results solely from the candidate implementation or an agent explanation.',
'Model authorization, execution outcome and acceptance as separate controls. A permitted test can fail; an accepted artifact may still lack deployment permission. Treat skips, missing tools and absent evidence explicitly instead of folding them into success.',
'Capture immutable observations with command/method, environment, exit/result, artifact hash and hashes of implementation, oracle, configuration and contract. Include dirty/untracked inputs when relevant. A Git commit alone is insufficient.',
'Evaluate each criterion against its declared oracle. Use approved, rejected, unverified, inconclusive and justified not-applicable states, mapped to the consumer vocabulary. Contradictory observations require investigation, not majority voting among agents.',
'Build a dependency map from observed inputs to criteria. Change one input in a disposable fixture and confirm only dependent observations become stale; changing the oracle or criterion itself also invalidates affected acceptance.',
'Introduce representative defects into a controlled candidate and confirm the oracle rejects them. Preserve the failing and repaired results separately. Deliver a per-criterion verdict table, residual work and exact replay instructions; stop retries when they require missing authority or an unchanged external dependency.'
],
'refs':{
'acceptance-verdicts':'''# Verdicts and authorization

A verdict answers whether evidence supports a criterion for a particular input state. It does not authorize execution, publication or access. Keep at least these distinctions: observed support; observed contradiction; no verification; observations insufficient/conflicting; explicitly out of scope with reason.

Example: a test executable is absent. The execution record says unavailable and the criterion is unverified. Exit code zero from a wrapper that skipped tests cannot override this. If a real test failed because the claimed behavior is violated, report rejected; if the environment prevented reaching the assertion, report the environment gap without claiming behavior passed.

Aggregate only the mandatory criteria for the declared scope. One approved build criterion cannot approve recovery, accessibility or sandboxing. An agent's done message is an input to investigation, not a verdict. A deployment gate must separately inspect current authorization even if every acceptance criterion passed.
''',
'evidence-provenance':'''# Content-bound observations

An observation should identify subject, method, actor/tool, time, environment, inputs and result artifact. [SLSA provenance v1.2](https://slsa.dev/spec/v1.2/provenance) is useful for distinguishing how an artifact was produced from whether it satisfies a functional requirement; adopting these design ideas does not claim SLSA compliance.

Hash bytes actually observed. Keep the old record when an input changes; append a new observation after rerunning or reexamining the relevant method. Hash equality supports identity, not authenticity or adequacy of an oracle. Include fixtures, configuration and the acceptance contract as dependencies, not only source code.

For a cache of verdicts, compute freshness from the dependency set. If evidence E covers code A and oracle X, changing unrelated B should not invalidate E; changing X must. Recovery should display stale evidence as historical until the required method has run against current inputs. Never update hashes around an old result to make it look fresh.
''',
'independent-oracles':'''# Challenge the oracle

Choose an independently specified invariant: a known input/output pair, a protocol rule, a conserved quantity or a forbidden effect. A second implementation copied from the first is not automatically independent; neither is another agent repeating the same premise.

Construct a representative defect that matters to the claim. For a freshness gate, alter a bound file after recording a passing result. For permission separation, give a passing artifact to a deployment mock without a grant. For skipped tests, return an empty test set with wrapper exit zero. Observe the gate refuse approval in all relevant cases.

Keep mutation confined to disposable fixtures. A mock can show that a decision path rejects a missing permission; only an authorized integration can show that a real publication endpoint enforces it. Report both layers distinctly. Do not replace the original acceptance criterion with the easier mock property.
'''}},
'workspace-integrity-engineering':{
'description':'Protect multiauthor workspaces through content preconditions, path boundaries, conflict detection and crash recovery. Use for concurrent file edits, watchers and Git worktrees; skip ordinary schema migrations.',
'steps':[
'Inventory authorized roots, existing dirty and untracked files, symlinks, external writers, filesystem and Git availability. Capture a recoverable content baseline for the intended write set; Git status alone does not preserve unstaged or untracked bytes.',
'Bind each proposed edit to an observed base hash and destination identity. Compare immediately before commit; a mismatched base becomes a conflict, never a blind overwrite. A merge requires independent verification and retention of both inputs.',
'Constrain path resolution and the actual operation. Reject traversal and escaping symlinks; consider case normalization, mount boundaries and races. Canonicalizing once before opening is not a complete defense against TOCTOU. Use suitable platform primitives or explicitly narrow the threat model.',
'Prepare staging, a journal and recovery points. Distinguish atomic replacement of one path from durability and from a multi-file transaction. Record which writes are committed, uncertain or still staged when a crash interrupts the sequence.',
'Treat watcher events as hints. Reconcile from file contents after overflow, rename bursts or restart; invalidate snapshots of changed files and downstream indices. If worktrees are used, inspect shared repository metadata and serialize conflicting Git operations.',
'Exercise path escape, two writers from one base, failure before/after replacement and external mutation with missed watcher events. Deliver a conflict policy, restoration procedure and observed platform limits; never restore a baseline over newer unrelated work.'
],
'refs':{
'file-operations':'''# Safe write boundaries

A write intent contains root identity, relative path, base hash, proposed bytes/hash and operation kind. Validate both the input path and the object reached at the moment of use. String-prefix checks confuse sibling roots; simple canonicalization can race with symlink replacement. Choose platform capabilities appropriate to the trust model and test them on the target OS.

Use a same-filesystem temporary file when replacement semantics are required. [Rust rename](https://doc.rust-lang.org/std/fs/fn.rename.html) documents cross-filesystem failure and platform differences. Rename alone does not provide a portable multi-file transaction or proof of durability.

For crash recovery, journal intended/base/new identities and commit progress. On restart compare actual bytes with both base and staged hashes. If neither matches, preserve all candidates and report conflict. Do not infer completion merely because the temporary file disappeared. Tests should inject failure between staging, flushing, replacement and completion recording.
''',
'git-worktrees-and-conflicts':'''# Git is context, not a backup of all bytes

[Git worktree](https://git-scm.com/docs/git-worktree) provides separate working trees while some repository state is shared. Inspect worktree list/status and branch ownership before choosing an isolated task location. Never prune, reset, clean or remove a worktree as routine recovery without checking ownership and outstanding changes.

For concurrent writers use an explicit base version: writer A and writer B read H0; A commits H1; B must detect H1 before writing H2. A timestamp check alone can miss same-tick edits. Preserve B's proposal and H1 for a three-way merge against H0; accept the merge only after checking semantics.

Without Git, use a content manifest and recoverable snapshots. With Git, retain dirty, ignored and untracked files relevant to the operation. A clean commit ID does not identify the current filesystem if files changed afterward. Separate Git coordination from filesystem locking and acknowledge noncooperating external writers.
''',
'watcher-and-recovery':'''# Reconcile after lost events

Model the watcher as an invalidation hint stream, not an authoritative transaction log. Events can coalesce, overflow or arrive after the underlying file has changed again. On a hint, read the current identity/content under the project's limits; publish an updated snapshot only after the read is validated.

After overflow or restart, mark the affected scope uncertain and perform a bounded rescan. Deleted files need tombstones so old symbols and graph edges do not remain visible. Renames may be represented as delete/create when identity cannot be proven; do not invent a stable identity from matching basenames.

Recovery matrix: staged-only → retain or discard under ownership policy; committed bytes/no completion record → reconcile from hash; unexpected bytes → conflict; unavailable mount → defer, not delete. Test an edit with deliberately suppressed watcher delivery and verify that reconciliation still invalidates stale consumers.
'''}},
'iced-engineering':{
'description':'Implement and review Iced desktop interfaces using explicit state, messages, tasks, subscriptions and widget contracts. Use for Iced-specific rendering and interaction; skip non-Iced UIs and visual strategy alone.',
'steps':[
'Read the actual manifest, lockfile, enabled features and Iced version before naming APIs. Compare that version with documentation. If no consumer exists, provide version-scoped design guidance and mark compilation/integration unverified instead of inventing a Cargo workspace.',
'Define state and Message transitions independently of widgets. Route effects through tasks and results through messages with request/generation identity. Ignore stale results after navigation or cancellation. Keep process/session state outside presentation state.',
'Keep view construction free of blocking IO and expensive layout algorithms. Task-based scheduling alone does not make CPU-bound work cooperative: choose a worker strategy compatible with the configured executor. Bound queues and coalesce render-only updates without dropping evidence.',
'Design subscription lifetime from active state and stable identity. Remove or suspend expensive producers when their view is inactive; explicitly cancel independently owned work. Guard late replies so a hidden or reopened panel cannot apply obsolete results.',
'Prefer composition of existing widgets. For custom widgets verify the selected version\'s layout, event propagation, focus, accessibility, operation and drawing contracts. Define pane IDs and layout persistence separately from content, with safe restoration on smaller screens.',
'Test slow work with a UI heartbeat, keyboard focus across collapse/expand, extreme window sizes, loading/error/empty states and hidden-view work counters. Report platform/hardware and measurement limits; no universal latency or accessibility guarantee follows from Iced.'
],
'refs':{
'message-update-state':'''# Message, update, effects

The consulted [Iced 0.14.0 guide](https://docs.rs/iced/0.14.0/iced/) uses state, Message, update and view; update may return Task and subscriptions describe active streams. These names are version-scoped, not a mandate to upgrade a consumer.

Design a search transition: QueryChanged stores text and increments generation; StartSearch emits work tagged with that generation; SearchFinished applies only if generation still matches. Failure becomes an explicit state with retry semantics. A panel being closed should not make a late result mutate a different panel that reused its visual position.

Keep a pure transition table for ordinary tests and an integration test for scheduling. An async function that performs a long synchronous loop may still block its executor. Verify worker choice and cancellation behavior under real load. UI state can display an execution verdict but must not calculate a second acceptance authority from message text.
''',
'layout-and-custom-widgets':'''# Layout, panes and custom widgets

Start with standard composition and stable content IDs. Persist logical pane placement and user preferences, then validate restored geometry against the current screen. Preserve content when a panel collapses; define whether focus moves to its toggle or another visible control. Reopening should restore a valid target rather than an invisible focused node.

Check the exact pane-grid and advanced Widget APIs in the installed Iced version before implementing callbacks or trait methods. The dedicated 0.14.0 pane-grid/Widget documentation URLs were unavailable during this authorship; no signatures from them are asserted here. Resolve this gap from versioned source/docs when applying the skill.

For a custom node view, specify hit testing, keyboard traversal, selected/hover/focus states, event capture versus propagation, clipping, scaling and accessible semantics. Test narrow/short windows and large text. A visually correct canvas does not establish keyboard or assistive-technology support.
''',
'desktop-performance-and-accessibility':'''# Responsiveness and accessibility evidence

Instrument input receipt, update completion, frame presentation where available, queue length and worker activity. Define a workload and hardware before setting thresholds. Compare idle, active computation, burst events and hidden panels; report percentile latency only from an actual sample with its size and method.

Cache heavy layouts by data generation and relevant layout parameters. When a graph is hidden, stop scheduling its layout and redraw triggers; preserving the last cache is different from keeping a loop alive. Cancellation and stale-result checks are both needed when computation is already running.

Review keyboard-only navigation, focus restoration, contrast, scale, labels and non-color state indicators. Test assistive technology on each supported platform before claiming accessibility. A state-transition unit test covers neither screen-reader output nor frame timing. Capture failures and explicit platform gaps alongside successful observations.
'''}},
'code-context-engineering':{
'description':'Engineer incremental code indexing and retrieval with snapshot-bound symbols, ranges, invalidation and semantic fallback. Use for repository context engines; skip generic document RAG and graph visualization alone.',
'steps':[
'Identify the repository snapshot including dirty files, ignore rules, languages and parser/semantic-provider versions. Define resource and privacy limits before scanning; start with paths/text when they answer the query.',
'Define document identity, content hash, range encoding and symbol identity separately. Store extraction method, parser version and originating snapshot on every result. Preserve ambiguous identities instead of conflating homonyms.',
'Build invalidation from changed documents to dependent symbol/reference entries. Stage new generations and publish coherent snapshots; represent deletes and renames. If watcher delivery is uncertain, reconcile bounded scopes from actual content.',
'Use parsing for syntax and a semantic provider only when resolution is needed and authorized. Negotiate LSP capabilities and position encoding; an AST call expression does not identify its callee. Missing providers cause labeled degradation, not invented resolution.',
'At retrieval, verify content hash before slicing the original file. Return path, range, snapshot, method and freshness; explicitly label truncated, stale or unavailable results. Retrieved text remains data without authority to request tools.',
'Evaluate on a versioned corpus with known symbol positions, rename/edit mutations, ambiguous calls and absent LSP. Compare with simple textual search for precision/recall and resource use. Deliver the index contract and replayable query cases, not a claimed model-quality improvement without measurement.'
],
'refs':{
'incremental-indexing':'''# Generation-based index updates

Key a document by workspace identity and canonical project path, with a content hash distinct from its identity. A generation records parser configuration and input hashes. Stage changed entries and tombstones before publishing the generation; readers should not accidentally combine old definitions with new references.

[Tree-sitter advanced parsing](https://tree-sitter.github.io/tree-sitter/using-parsers/3-advanced-parsing.html) describes applying edits to the old tree before incremental parsing and updating retained node positions. This is syntax maintenance, not semantic call resolution. If using another parser, verify its invalidation contract rather than importing these API assumptions.

A rename can preserve conceptual symbol identity while changing file identity; require evidence for that mapping. If uncertain, remove/add with a documented alias rather than retaining stale offsets. Test delete, rename, ignored-file transition, parser failure and lost watcher event. Failed parsing should leave an explicit unavailable/stale generation, not a silently current old index.
''',
'symbols-and-resolution':'''# Identity and resolution strength

Separate syntax facts, semantic resolution and inferred similarity. A function-call token plus a matching name elsewhere is a candidate relation; overloads, imports, macros and dynamic dispatch can prevent unique resolution. Report candidate sets and the missing semantic context.

Consult the [LSP 3.17 specification](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/) for capability negotiation, document synchronization and position encoding before implementing an adapter. Record server version, document version and configuration with the result. Do not assume byte offsets equal protocol character positions; include non-ASCII fixtures.

Before returning a range, read the actual bytes and compare the expected hash. If it differs, refresh or label the result stale. A useful test uses two modules defining the same name plus a multibyte character before the call: the oracle checks both identity uncertainty and range conversion. LSP unavailability should retain path/text search with reduced guarantees.
''',
'retrieval-evaluation':'''# Evaluate retrieval, then downstream utility

Create a corpus with held-out queries and independently annotated relevant locations. Track exact-match/range correctness separately from semantic usefulness. Count an obsolete result as a freshness failure even if its text remains plausible.

Compare path/text search, structural indexing and optional semantic enrichment under the same query set and snapshot. Record index build/update work, query latency, memory and retrieved volume; report precision and recall with their denominators. Do not select embeddings merely because a graph or an agent exists.

For downstream claims, run paired task evaluations with comparable budgets and permissions. Retrieval metrics do not prove task completion. Synthetic fixtures can verify mutation invalidation and range identity now; claims about real repositories, multilingual coverage or agent success require observed evaluations on those inputs.
'''}},
'code-knowledge-graph-engineering':{
'description':'Design typed code knowledge graphs with evidence-backed edges, incremental invalidation and bounded impact queries. Use for code relationship semantics; skip static diagrams and embedding similarity presented as resolved calls.',
'steps':[
'Define node identity, edge type, direction, cardinality and evidence requirements before choosing a graph store. Separate structural relations, semantic resolution and inference with incompatible labels when appropriate.',
'Attach snapshot, source range, extraction method/version and originating evidence to every edge. A numeric similarity score cannot upgrade an inferred edge to verified. Validate endpoint existence in the same generation.',
'Publish incremental updates coherently: remove or invalidate edges dependent on changed/deleted evidence, then add replacements. Retain historical generations for traceability without exposing them as current.',
'Define query semantics and bounds: permitted edge classes, direction, depth, node/edge limits, timeout, cancellation and truncation metadata. Traverse with visited sets to handle cycles and deduplicate stable identities.',
'Keep logical graph data separate from layout. Structural and dense exploratory views should project the same snapshot with different filters; cluster membership/layout position is not a new factual edge. Pause expensive layout when hidden.',
'Test known calls, mislabeled inferences, deleted sources and a deterministic dense cyclic graph. Check provenance, orphan handling and explicit truncation. Deliver schema, bounded queries, before/after fixtures and UI-performance gaps separately.'
],
'refs':{
'graph-schema-and-evidence':'''# Evidence-bearing graph schema

A design record for an edge can include id, source_node, target_node, relation_type, evidence_class, snapshot, source_range, producer_version and evidence_locator. Define which fields are required per edge class. Reject a resolved call without resolution evidence rather than accepting a boolean verified flag supplied by an inference producer.

The [W3C PROV data model](https://www.w3.org/TR/prov-dm/) distinguishes entities, activities and agents. It is a useful vocabulary for attributing an extraction to inputs and a producer; this skill does not require RDF or PROV conformance.

Two independent producers can disagree. Keep their claims separate with source identities and a conflict state; do not collapse them into one stronger claim. A path from file A to B through inferred edges is exploratory context, not proof that changing A breaks B. State the allowed evidence classes in every impact query.
''',
'incremental-graph-updates':'''# Remove stale relationships deliberately

Maintain reverse dependencies from evidence locations/documents to edges. On a new snapshot, invalidate affected edges before publishing replacements. A deleted function must not remain as a current node merely because a cached layout refers to it.

Use a staged generation or transaction suitable for the selected store. Verify endpoint and evidence consistency before switching readers. If extraction fails midway, keep a coherent previous snapshot labeled stale or publish partial coverage explicitly; do not mix generations without a coverage contract.

Fixture: snapshot S0 contains A calls B. In S1, remove that call and introduce an unrelated C. Assert the A→B edge is absent from S1, present only in historical S0, and queries for C do not inherit B's evidence. Test duplicates, rename ambiguity and dangling endpoints. Store-specific transaction mechanics belong to a persistence specialist only if unresolved.
''',
'graph-queries-and-visualization':'''# Bounded traversal and honest views

An impact query must name root, direction, edge classes, snapshot and maximum work. Keep visited nodes to terminate cycles; bound both nodes and edges because a small node set may still have many edges. Return a truncation flag, reason and continuation semantics when work is limited.

Use deterministic tie-breaking for repeatable tests. A corpus with a cycle, a high-degree hub and inferred links should produce a stable bounded result without hiding omitted neighbors. Depth zero and a missing root need explicit behavior.

Structural and dense views share graph identities and provenance; layout caches include snapshot and filter parameters. Selecting a node should resolve to its evidence, not a stale display index. A bounded query test does not establish responsive rendering: measure layout, input latency and cancellation on target hardware separately.
'''}},
'tool-output-engineering':{
'description':'Transform CLI output conservatively while preserving raw bytes, exit status, failure signals and explicit loss metadata. Use for tool parsers and token-budget summaries; skip destructive audit-log rewriting.',
'steps':[
'Capture stdout and stderr bytes with execution identity, ordering limits, exit/signal status and retention policy before transformation. Hash and locate raw artifacts; if capture is incomplete, say so rather than promising a complete raw log.',
'Identify tool/version/output format and choose a matching parser. Preserve unknown records. Treat encoding errors, ANSI, binary content and partial frames as conditions for explicit conservative fallback, not automatic success.',
'Normalize observations without overwriting the raw source. Keep failure status, error locations, skipped tests and parser diagnostics. Distinguish tool failure from failure to understand its output.',
'Build a compact projection with an explicit budget, omission/truncation metadata and raw offsets/locators. Prioritize consequential failures but disclose when the budget cannot contain all of them. Sanitize terminal controls in the display layer, retaining original bytes under access policy.',
'Keep output as untrusted data. Instructions embedded in logs cannot grant permission or become tool calls. Apply redaction to authorized views and protect raw access/retention; preserving bytes does not authorize exposing secrets.',
'Use differential fixtures to compare raw, structured and compact failure signals. Include unknown format, partial UTF-8, binary, ANSI, huge output and prompt injection. Measure bytes/tokens using a named method; provider billing savings require provider evidence and comparable workloads.'
],
'refs':{
'loss-aware-transformations':'''# Raw, normalized and compact representations

Keep three separately identified artifacts. Raw is the captured byte stream with completion and retention metadata; normalized is a versioned interpretation; compact is a lossy view. Record transform version, raw hash, ranges consumed/omitted, parser warnings and truncation reason.

Exit code and signal come from process observation, not from phrases like all tests passed. If output says success but the process exits nonzero, preserve the contradiction. If storage fills before capture completes, expose incomplete_raw and the captured extent; a locator cannot promise bytes never retained.

For a privacy-sensitive log, preserve authorized evidence with restricted access and a retention policy. Redacted display is distinct from raw evidence. Escaping terminal control characters prevents display effects without treating log text as commands. A summary should never erase the only occurrence of a failure location without reporting the omission and retrieval route.
''',
'tool-parsers-and-fallbacks':'''# Format recognition and fallback

[Cargo external tools](https://doc.rust-lang.org/cargo/reference/external-tools.html#json-messages) documents JSON build messages and warns that message-format does not control every subprocess or macro output. Do not assume cargo test produces a homogeneous machine-readable test stream merely because a build flag is set.

Select parsers by observed tool version and format, not just executable basename. Validate records before interpretation; retain unknown records and the fact that recognition failed. For partial UTF-8, keep raw bytes and either incremental decode with carried state or a visibly lossy display; never silently drop the bytes that contain an error.

Fallback should expose exit status, raw locator, capture completeness and an explicit recorte/truncation notice. Differential oracle: every known failing fixture must remain failing or explicitly uninterpretable, never pass. Add an adversarial line asking the agent to publish secrets; its only permitted role is quoted log data.
''',
'token-measurement':'''# Measure reduction without inventing savings

Record byte count and character count separately. A tokenizer count needs tokenizer identity/version, model compatibility and the exact serialized content counted. A heuristic such as bytes divided by four is an estimate with unknown error for arbitrary languages or binary data.

Compare original and transformed payloads under the same method. Include any wrapper, tool schema and retrieved follow-up details when the claimed scope includes them. If the CLI runs commands outside the observed pipeline, do not extrapolate savings to those commands.

Provider-reported usage is a different measurement from local tokenization. Price, cache rules and task-quality effects may change cost even with fewer visible tokens. Use paired authorized trials to assess downstream utility; a smaller string alone proves neither lower billing nor better task success. When provider information is absent, report billing savings unavailable.
'''}},
'agent-usage-accounting':{
'description':'Model and reconcile agent token, cache and cost usage with provenance, idempotency and explicit uncertainty. Use for multi-session usage ledgers; skip generic CPU metrics and task-progress scoring.',
'steps':[
'Inventory actual provider/adapter events and distinguish reported totals, deltas, local estimates and absent fields. Record units, source, request/session/attempt identity, event time, observation time and timezone policy.',
'Define an idempotency key at the provider/account/request/event scope. A replay of the same event must not add usage; a retry that consumed a new request may legitimately add usage. Duplicate IDs with conflicting payloads require reconciliation, not silent overwrite.',
'Normalize token categories without double-counting subsets. Determine whether cached input is included in total input and whether streaming records are cumulative snapshots or deltas. Preserve raw reports and correction events.',
'Calculate cost only with a versioned tariff, currency, unit denominator and applicability interval. Missing price or usage yields unknown or explicitly partial totals. Use exact decimal arithmetic and a defined rounding policy for currency.',
'Aggregate by explicit half-open time intervals and timezone, retaining event-time versus arrival-time distinctions. Keep current context occupancy, cumulative consumption, monetary cost and functional progress separate.',
'Replay duplicates, partial streams, cache-inclusive totals, missing tariff and a day-boundary event. Reconcile with the observed provider contract without exposing content/credentials. Deliver ledger schema, aggregation examples and uncertainty labels; telemetry conventions alone do not certify an invoice.'
],
'refs':{
'usage-event-schema':'''# Usage event identity

Suggested design fields: provider/account scope, request_id, attempt_id, event_id, sequence, occurred_at, observed_at, metric_kind, token_category, value, unit, precision, source_locator and contract_version. Record whether a value is a delta or cumulative snapshot. Null/unavailable is distinct from zero measured usage.

The consulted [OpenTelemetry GenAI attributes](https://opentelemetry.io/docs/specs/semconv/registry/attributes/gen-ai/) distinguish input/output and cache token attributes. Verify each adapter's meaning before mapping fields; convention stability and provider support can vary. This is an interoperability reference, not a billing contract.

Do not use prompt contents as a deduplication key or store secrets for correlation. A provider request ID may be unique only within an account. Preserve conflicting payloads with a reconciliation status so an ingestion bug cannot silently rewrite measured history.
''',
'accounting-and-reconciliation':'''# Replay, corrections and totals

Example contract: input_total=100, cached_input=30 (a subset), output=20. Total tokens are 120, not 150. A different provider may report exclusive categories; require its actual contract before applying either formula.

For cumulative streaming usage 10 then 15, use the latest valid cumulative value for that request, not 25. For delta events 10 then 15 with distinct IDs, sum 25. A repeated event ID with identical payload contributes nothing new; the same ID with changed payload is a conflict or explicit correction according to the source contract. A new billed retry has a new request identity and should not be suppressed as a transport replay.

Retain append-only observations and explicit adjustments. Reconcile provider totals against ingested request totals by interval, scope and completeness; show gaps instead of filling missing usage with zeros. Test out-of-order delivery and partially closed sessions.
''',
'context-and-cost-estimates':'''# Time, context and price

Specify intervals as [start, end) in an explicit reporting timezone. Convert event timestamps consistently and test midnight and daylight-saving boundaries where applicable. Late events may revise a period view while preserving the original observations and report version.

Context occupancy is a snapshot of an active request/window; daily token consumption is an accumulation. Neither implies task progress. Unknown context capacity or hidden agent messages prevent an exact occupancy percentage.

For cost, record tariff source, effective period, currency, per-unit denominator, cache categories and rounding. A local estimate can be useful if labeled; it is not a measured invoice. A missing tariff yields unknown cost even when tokens are measured. A partial total should display known cost plus unknown coverage, not a deceptively complete number. No live prices or provider subscriptions are assumed by this skill.
'''}}
}
for name,data in DATA.items():
    block=re.search(r'### 8\.\d+ `'+re.escape(name)+r'`.*?(?=\n### 8\.\d+ |\n## 9\.)',source,re.S)[0]
    def field(label): return re.search(r'\*\*'+re.escape(label)+r':\*\* (.*)',block)[1]
    folder=root/'.codex/skills'/name
    assert not folder.exists(),folder
    (folder/'references').mkdir(parents=True)
    refs='\n'.join(f'- [{key}](references/{key}.md): consultar para '+content.splitlines()[0].lstrip('# ') +'.' for key,content in data['refs'].items())
    body=f'''---
name: {name}
description: {data['description']}
metadata:
  version: "1.0.0"
---

# {name}

## Responsabilidade e seleção

{field('Responsabilidade')}

Selecionar: {field('Ativar')}

Não selecionar: {field('Não ativar')}

## Entradas e lacunas

{field('Entradas')}

Inspecione os contratos e recursos reais antes de executar. Ausência de versão exige consulta à documentação correspondente; ausência de permissão impede o efeito dependente. Registre a lacuna, seu impacto e como resolvê-la, continuando partes independentes. Os exemplos deste pacote são contratos de avaliação, não APIs ou políticas impostas a todos os consumidores.

## Procedimento operacional

'''+ '\n\n'.join(f'{i}. {s}' for i,s in enumerate(data['steps'],1))+f'''

## Entregáveis e aceitação

{field('Saídas')}

Vincule cada conclusão a input observado, método, resultado e limite. Execute casos esperados, de borda e de falha de [avaliações](references/evaluation-cases.md) no ambiente autorizado; diferencie resultado de revisão, simulação e integração. Casos apenas escritos continuam não executados. O texto da skill não prova eficácia nem concede autoridade.

## Fronteiras e encaminhamento

{field('Skill auxiliar condicional')}

Encaminhe somente a pergunta técnica distinta ainda não resolvida, com escopo, IDs de critérios, fatos, lacunas e evidência requerida. Confirme disponibilidade antes da consulta. Uma menção não instala, delega, executa nem carrega recursivamente outras skills. A autoridade de comportamento pertence ao contrato do consumidor; a skill oferece o método.

## Referências especializadas

{refs}

Fontes oficiais acessadas em 2026-10-26 são citadas junto às afirmações. Versão consultada não é versão adotada pelo consumidor. Sínteses operacionais e esquemas de exemplo são decisões de método desta skill, sem promessa de implementação ou compatibilidade futura.
'''
    (folder/'SKILL.md').write_text(body)
    for key,content in data['refs'].items(): (folder/'references'/f'{key}.md').write_text(content)
    # Preserve the exact proposed requirements and acceptance statements.
    reqs=re.findall(r'^- REQ-\d+:.*$',block,re.M)
    acs=re.findall(r'^- AC-\d+ → REQ-\d+:.*$',block,re.M)
    cases='# Avaliações da skill\n\nContrato de casos; execução deve ser registrada separadamente. Não constituem testes realizados.\n\n## Cenários técnicos preservados\n\n'+'\n'.join(acs)+'\n\n## Protocolo de avaliação\n\nForneça um pedido concreto e os inputs mínimos a um agente em diretório isolado autorizado. Na rodada de seleção, mostre somente catálogo/descriptions, sem a resposta esperada. Na rodada de comportamento, disponibilize a skill selecionada e os dados adversos. Preserve prompt, resposta bruta, identidade/configuração conhecida do agente, hashes dos inputs, revisão do resultado e limitações. Não execute serviços ou ferramentas com novas permissões.\n\nSeleção positiva: pedir o entregável próprio descrito nesta entrada. Seleção negativa: usar a exclusão explícita; a resposta deve apontar competência mais adequada sem carregar esta skill. Falha: fornecer input que contraria o cenário técnico e exigir evidência antes de aprovação. Os prompts concretos do pacote consumidor devem incluir dados suficientes e um oráculo independente.\n'
    (folder/'references/evaluation-cases.md').write_text(cases)
    bridge=re.search(r'````markdown\n(.*?)\n````',block,re.S)[1].replace('skill_path: UNCONFIGURED',f'skill_path: .codex/skills/{name}/SKILL.md')
    (root/'sdd/chain'/f'{name}.md').write_text(bridge+'\n')
    feature=root/'sdd/features'/f'skill-{name}'; feature.mkdir()
    (feature/'spec.md').write_text(f'''# Autoria e avaliação de {name}

Origem: seção 8 do comparativo preservado na raiz. Ator: mantenedor/avaliador da skill. Precondição: autoria autorizada e avaliação em ambiente permitido. Esta feature pertence à biblioteca; não é feature do produto Ox.

## Contratos técnicos preservados

As declarações abaixo mantêm IDs, cenários e oráculos propostos. REQ-01..03 são competências que a skill deve ensinar. AC-01..04 exigem exercitar entregáveis concretos; revisão textual sozinha não os aprova. Integrações de produto/plataforma permanecem futuras quando não disponíveis.

'''+ '\n'.join(reqs)+'\n\n'+'\n'.join(acs)+'''

## Critérios adicionais da autoria

- REQ-04: Entregar método reutilizável com seleção precisa, entradas, referências e cenários verificáveis.
- AC-05 → REQ-04: Revisão de conteúdo e validação local confirmam entrada completa, referências substantivas, fronteiras e ponte válida.
- AC-06 → REQ-04: Ensaio observado com agente distingue pedido positivo, negativo e comportamento adverso; limitações e resposta bruta preservadas.

Não substituir AC-01..04 por AC-05/06. Versões, plataforma, dados e autorização do consumidor precisam ser conhecidos antes da integração. A aprovação da skill não aprova subsistemas do produto.
''')
    decisions=re.search(r'#### SDD — `plan.md`\n(.*?)\n\*\*Métodos selecionados:',block,re.S)[1]
    proposed_tasks=re.findall(r'^- \[ \] T00[1-4].*$',block,re.M)
    (feature/'plan.md').write_text(f'''# Plano de autoria de {name}

Rota completa por contrato de competência, fronteiras e critérios de avaliação. Autoridade: spec desta feature e constituição do consumidor para efeitos autorizados.

## Alternativas técnicas preservadas

As escolhas abaixo são alternativas de método a ensinar/avaliar, não decisões técnicas aprovadas do Ox.

{decisions}

D-03 [REQ-04]: criar entrada, três referências especializadas e casos próprios em vez de duplicar uma skill geral; custo de manutenção justificado pelas seções 6 e 8 do comparativo. R-03 [REQ-04]: seleção ambígua ou texto superficial; verificar com casos positivos, negativos e falha. Reavaliar após uso observado ou mudança das fontes.

## Seleção de métodos e dependências

Método primário de autoria efetivamente consultado: skill-creator do ambiente (versão não declarada; cópia de consulta em docs/validation/adoption-baseline/skill-creator.md). Sem ponte local para esse método. Esta nova skill não existia na seleção inicial e não é declarada consultada na própria autoria.

A ponte sdd/chain/{name}.md, bridge_version 1, e entrada .codex/skills/{name}/SKILL.md ficam disponíveis para consumidores e avaliação posterior; existência não prova consulta. Auxiliar condicional proposta: {field('Skill auxiliar condicional')} Sem consulta automática.

Dependências de autoria: protocolo → runtime → verificação; workspace/Iced completam fundação; contexto antecede grafo; output e uso dependem do vocabulário de eventos. Não são dependências de instalação.

## Atividades técnicas propostas a ensinar e retomar

'''+ '\n'.join('> '+line.replace('T00','P00',1) for line in proposed_tasks)+'''

P001..P004 preservam a intenção das tarefas propostas; não declaram implementação do produto. A execução local de autoria está em tasks.md. Testes reais dependem de consumidor e escopo autorizado.
''')
    (feature/'tasks.md').write_text(f'''# Tarefas — {name}

- [x] T001 [REQ-01, REQ-02, REQ-03, AC-01, AC-02, AC-03, AC-04, D-01, R-01]: preservar contratos e definir cenários; spec.md e referências; sem dependências; concluída a preparação, não a integração.
- [x] T002 [REQ-04, AC-05, D-03, R-03]: autorar .codex/skills/{name}/SKILL.md, referências e ponte; depende T001; conteúdo materializado e sujeito à revisão.
- [ ] T003 [REQ-04, AC-05, AC-06, D-03, R-03]: validar estrutura, revisar conteúdo e executar casos controlados de seleção/comportamento; depende T002; preservar inputs e respostas.
- [ ] T004 [REQ-01, REQ-02, REQ-03, AC-01, AC-02, AC-03, AC-04, D-01, D-02, R-01, R-02]: exercitar os quatro cenários técnicos em consumidor autorizado com os oráculos da spec; depende T003 e disponibilidade de implementação/ambiente; não implementar Ox nesta tarefa.
- [ ] T005 [REQ-04, AC-05, AC-06, D-03, R-03]: registrar convergência e evidência schema 2 após estabilizar inputs; depende T003; distinguir pendências de T004.
''')
    trace=[]
    for i,ac in enumerate(acs,1): trace.append({'acceptance':f'AC-{i:02d}','requirement':re.search(r'→ (REQ-\d+)',ac)[1],'decision':'D-01','risk':'R-01','tasks':['T001','T004'],'implementation':f'.codex/skills/{name}/SKILL.md','oracle':f'.codex/skills/{name}/references/evaluation-cases.md'})
    for i in [5,6]: trace.append({'acceptance':f'AC-{i:02d}','requirement':'REQ-04','decision':'D-03','risk':'R-03','tasks':['T002','T003','T005'],'implementation':f'.codex/skills/{name}/SKILL.md','oracle':f'.codex/skills/{name}/references/evaluation-cases.md'})
    (feature/'traceability.json').write_text(json.dumps(trace,ensure_ascii=False,indent=2)+'\n')
    (feature/'evidence.json').write_text(json.dumps({'schema_version':2,'environment':'Autoria local; integração e avaliação ainda não executadas.','requirements':[{'id':f'AC-{i:02d}','criterion':line,'status':'NÃO VERIFICADO','evidence_ids':[]} for i,line in enumerate(acs+['Revisão de autoria','Avaliação com agente'],1)],'evidence':[],'limitations':['Não há aplicação consumidora implementada; cenários de integração não executados.']},ensure_ascii=False,indent=2)+'\n')
    (feature/'converge.md').write_text('# Convergência inicial\n\nAC-01..06: NÃO VERIFICADO. Autoria materializada; avaliação e integração têm critérios separados. Retomar T003 para revisão/casos e T004 somente em consumidor autorizado.\n')
print('Authored',len(DATA),'skills and SDDs.')
