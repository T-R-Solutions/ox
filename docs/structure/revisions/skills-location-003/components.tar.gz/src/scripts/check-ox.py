"""Read-only Ox profile and portability checks. Python 3.11+, stdlib only."""
from pathlib import Path
import hashlib, importlib.util, json, re, sys, tarfile
from urllib.parse import urlsplit, unquote
ROOT=Path(__file__).resolve().parents[2]
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_text())
def check(root):
    root=root.resolve(); errors=[]
    profile=read(root/'src/fixtures/profile.json')
    expected=set(profile['general'])|set(profile['conditional'])|set(profile['new'])
    actual={p.parent.name for p in (root/'.codex/skills').glob('*/SKILL.md')}
    if actual!=expected: errors.append('Skill inventory differs: '+str(actual^expected))
    if set(profile['excluded']) & {p.name for p in (root/'.codex/skills').iterdir()}: errors.append('Excluded skill installed')
    bridges={p.stem for p in (root/'sdd/chain').glob('*.md') if p.name!='README.md'}
    if bridges!=expected: errors.append('Bridge inventory differs')
    if [len(profile[k]) for k in ('general','conditional','new')]!=[17,3,9]: errors.append('Profile class counts differ')
    if (root/'sdd/model').exists(): errors.append('Nested model is not the adoption layout')
    originals=read(root/'docs/validation/adoption-baseline/originals.json')
    for rel,sha in originals.items():
        if not (root/rel).is_file() or digest(root/rel)!=sha: errors.append('Original modified: '+rel)
    manifest=read(root/'docs/structure/files.json')
    copies=manifest['revisions'][0]['records']
    # Existing skills must remain byte-identical, including every internal resource.
    copied_paths=set()
    for row in copies:
        rel=row['destination']; rel='.codex/'+rel if rel.startswith('skills/') else rel; copied_paths.add(rel)
        if rel.startswith('.codex/skills/') and (not (root/rel).is_file() or digest(root/rel)!=row['source_sha256']): errors.append('Copied resource changed/missing: '+rel)
        if row['copied_sha256']!=row['source_sha256']: errors.append('Invalid copy provenance: '+rel)
    for name in profile['general']+list(profile['conditional']):
        for p in (root/'.codex/skills'/name).rglob('*'):
            if p.is_file() and p.relative_to(root).as_posix() not in copied_paths: errors.append('Unexpected copied resource: '+str(p))
    # Baseline archive is self-contained; no source library access is needed.
    with tarfile.open(root/'docs/validation/adoption-baseline/copied-before-adaptation.tar.gz') as archive:
        for row in copies:
            stream=archive.extractfile(row['destination'])
            if stream is None or hashlib.sha256(stream.read()).hexdigest()!=row['source_sha256']: errors.append('Recovery baseline mismatch: '+row['destination'])
    stable=['workflow.md','evidence.md','tools/validate.py','README.md']
    stable+=['templates/'+p.name for p in (root/'sdd/templates').iterdir() if p.is_file()]
    source_hash={r['destination']:r['source_sha256'] for r in copies}
    for name in stable:
        if digest(root/'sdd'/name)!=source_hash['sdd/'+name]: errors.append('SDD core modified: '+name)
    # Check operational Markdown links against Ox, excluding preserved history/input sources.
    for p in root.rglob('*'):
        if p.is_symlink(): errors.append('Symlink not portable: '+str(p.relative_to(root))); continue
        if p.suffix!='.md' or not p.is_file(): continue
        rel=p.relative_to(root).as_posix()
        if p.name in originals or rel.startswith('docs/validation/adoption-baseline/') or '/runs/' in rel: continue
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',p.read_text()):
            parsed=urlsplit(target.strip('<>'))
            if parsed.scheme or parsed.netloc or not parsed.path: continue
            resolved=(p.parent/unquote(parsed.path)).resolve()
            if not resolved.is_relative_to(root) or not resolved.is_file(): errors.append(f'Broken/escaping link: {rel}: {target}')
    for name in profile['new']:
        p=root/'.codex/skills'/name/'SKILL.md'; text=p.read_text()
        if len(name)>64 or not re.search(r'^description: [^<>\n]{1,1024}$',text,re.M): errors.append('Invalid new metadata: '+name)
        if re.search(r'^\[TODO:',text,re.M): errors.append('Unfinished skill: '+name)
        if len(list((p.parent/'references').glob('*.md')))<4: errors.append('Missing specialized resources: '+name)
        feature=root/'sdd/features'/('skill-'+name)
        block=re.search(r'### 8\.\d+ `'+name+r'`.*?(?=\n### 8\.\d+ |\n## 9\.)',(root/'Ox_Comparativo_Skills_e_SDD_v1.0.md').read_text(),re.S)[0]
        for declaration in re.findall(r'^- (?:REQ-\d+:|AC-\d+ → REQ-\d+:).*$',block,re.M):
            if declaration not in (feature/'spec.md').read_text(): errors.append('Source criterion changed: '+name+': '+declaration)
    norm_source=set(re.findall(r'\*\*([A-Z]{3}-\d{3})\.\*\*',(root/'Ox_Regras_SDD_Skills_AGENTS_v1.0.md').read_text()))
    coverage=read(root/'src/fixtures/normative-coverage.json')
    if set(coverage)!=norm_source: errors.append('Normative coverage IDs missing/extra')
    for id,row in coverage.items():
        if not (root/row['authority']).is_file(): errors.append('Missing normative authority: '+id)
    return errors
if __name__=='__main__':
    try: errors=check(ROOT)
    except (OSError,ValueError,KeyError) as exc: print('FAIL:',exc); sys.exit(2)
    for error in errors: print('FAIL:',error)
    if not errors: print('PASS: 17 general + 3 conditional + 9 new skills; 29 bridges; copies, original hashes, SDD core, paths and normative coverage. Structural only.')
    sys.exit(bool(errors))
