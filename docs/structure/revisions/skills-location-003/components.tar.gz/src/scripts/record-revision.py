"""Append local component provenance; preserve earlier records and reviewed diffs."""
from pathlib import Path
import argparse,difflib,hashlib,json,tarfile
ROOT=Path(__file__).resolve().parents[2]
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--id',required=True);args=p.parse_args()
 if not args.id or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in args.id):p.error('lowercase revision id required')
 manifest=ROOT/'docs/structure/files.json';doc=json.loads(manifest.read_text())
 if any(r['id']==args.id for r in doc['revisions']):p.error('revision already exists')
 dest=ROOT/'docs/structure/revisions'/args.id;dest.mkdir(parents=True,exist_ok=False)
 prior={}
 for rev in doc['revisions']:
  for row in rev['records']:
   prior[row['destination']]=row.get('sha256',row.get('copied_sha256',row.get('source_sha256')))
 records=[];diff=[]
 with tarfile.open(ROOT/'docs/validation/adoption-baseline/copied-before-adaptation.tar.gz') as archive:
  members=set(archive.getnames())
  for row in doc['revisions'][0]['records']:
   rel=row['destination'];current='.codex/'+rel if rel.startswith('skills/') else rel;now=(ROOT/current).read_bytes();before=archive.extractfile(rel).read()
   if now!=before:
    diff.extend(difflib.unified_diff(before.decode().splitlines(True),now.decode().splitlines(True),fromfile='copied/'+rel,tofile='current/'+rel))
 # Track maintained components, not mutable observation outputs or a recursive self-hash.
 paths=[ROOT/'AGENTS.md',ROOT/'README.md',ROOT/'docs/constitution.md']
 for base in ['.codex/skills','sdd','src','docs/architecture','docs/decisions','docs/security']:
  paths.extend(p for p in (ROOT/base).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name not in {'evidence.json','converge.md'})
 with tarfile.open(dest/'components.tar.gz','w:gz') as archive:
  for path in sorted(set(paths)):
   rel=path.relative_to(ROOT).as_posix();data=path.read_bytes()
   archive.add(path,arcname=rel)
   if prior.get(rel)!=sha(data):records.append({'source':'local-authorship' if rel not in prior else 'prior-revision','destination':rel,'previous_sha256':prior.get(rel),'sha256':sha(data)})
 (dest/'reviewed.diff').write_text(''.join(diff))
 (dest/'review.md').write_text('# Revisão da revisão\n\nRevisor: agente executor. Diff das cópias confrontado com contratos de adoção; conteúdo autorado revisado em docs/validation/semantic-review.md. Alterações permitidas: paths/perfil de pontes, contexto do projeto e apontador constitucional. Skills existentes, workflow, evidence, templates e validador permanecem byte-idênticos. Sem revisão humana independente.\n')
 doc['revisions'].append({'id':args.id,'review':str((dest/'review.md').relative_to(ROOT)),'diff':str((dest/'reviewed.diff').relative_to(ROOT)),'snapshot':str((dest/'components.tar.gz').relative_to(ROOT)),'records':records})
 manifest.write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
 print('Appended',args.id,'records',len(records),'diff lines',len(diff))
if __name__=='__main__':main()
